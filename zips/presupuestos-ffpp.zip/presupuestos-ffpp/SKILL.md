---
name: "presupuestos-ffpp"
description: "Diligencia formularios de precios (FF PP) de subestaciones y obras eléctricas en Colombia: revisión del formato, estudio de mercado, APU, AIU, tabla contractual y textos humanizados, sin dañar macros, logos ni hojas ocultas. Úsala con \"llena este FF PP\", \"formulario de precios\", \"presupuesto de la subestación\", \"APU\". NO usar para hojas de cálculo genéricas (usar xlsx) ni para presupuestos de marketing."
---

# Presupuestos FF PP

Flujo para llenar un formulario de precios (FF PP) de obras eléctricas en Colombia y entregarlo listo para una oferta o un presupuesto de referencia. El entregable es el mismo archivo del cliente, en su formato original, con los campos vacíos llenos y cuatro hojas nuevas: Tabla Contractual, Estudio de Mercado, Soporte APU y Parámetros.

## 1. Revisar el formulario antes de tocarlo

- Listar hojas (incluidas las ocultas), columnas ocultas, imágenes, comentarios, nombres definidos y vínculos externos.
- Si es .xlsm, analizar las macros con `olevba` sin ejecutarlas.
- Identificar las columnas de precio (normalmente H suministro, J transporte, L montaje, N pruebas) y las celdas vacías.
- Buscar fórmulas faltantes en totales, filas de AIU sin fórmula, marcadores como "x", nombres de otra subestación copiados de otro proyecto y numeración repetida. Corregir lo evidente y avisarlo en el resumen final.
- Si el formato trae una base de precios oculta, confirmar que viene publicada con el proceso antes de usarla en una oferta para terceros.

## 2. Investigar el mercado

- Indicadores vigentes: salario mínimo y auxilio de transporte del año, IPC del año anterior, ICOCIV acumulado (DANE), jornada laboral vigente (Ley 2101) y medidas que muevan precios (aranceles, por ejemplo).
- Contratistas y fabricantes en Colombia para cada tipo de ítem, cada uno con fuente pública y experiencia verificable. Separar contratistas de montaje y fabricantes o distribuidores.
- Referencias de precio oficiales para contrastar (listas de precios de gobernaciones, ICCU, CYPE Colombia).
- Códigos UUCC según la Resolución CREG 015 de 2018; usar NIFT cuando no aplique y marcar con asterisco las UC asimiladas.

## 3. Hoja Parámetros

- Indicadores con su fuente.
- Costo por hora = (salario × factor prestacional + auxilio de transporte si el salario no pasa de 2 SMMLV) ÷ horas del mes.
- Cuadrillas, equipos y fletes con su fuente.
- AIU: calcular la administración desde costos reales (residente, SST, director, vehículo, campamento, pólizas, plazo). Si el formato solo aplica AIU sobre montaje y pruebas, explicar por qué el porcentaje sale alto y mostrar su equivalente sobre el costo directo total.
- Si otro formulario del mismo proyecto ya paga una actividad (por ejemplo el montaje), poner un interruptor SI/NO para no cobrarla dos veces, con NO por defecto.

## 4. Hoja Soporte APU

- Un bloque por ítem con columnas: ítem, columna destino, tipo (MAT, MO, EQ, TRA, HER, OTR), descripción, unidad, cantidad, precio, subtotal y fuente.
- Precios de mercado sin respaldo histórico en azul, para confirmar con cotización.
- Herramienta menor como porcentaje de la mano de obra del ítem, calculada solo sobre las filas anteriores (evita referencias circulares).
- Totales por columna en la fila de encabezado del ítem; el FF PP se enlaza a esos totales.

## 5. Formulario y tabla contractual

- Enlazar H, J, L y N al APU y completar las fórmulas faltantes siguiendo el patrón del propio formato.
- Tabla Contractual: valor unitario directo, valor unitario integral con AIU e IVA, resumen ligado al formulario, control de suma y condiciones contractuales sugeridas (modalidad, plazo, forma de pago, anticipo, pólizas, requisitos, normas, entregables, reajuste).

## 6. Estudio de Mercado (texto humanizado)

Secciones: Resumen (con cifras clave por fórmula), Objeto, Cómo se calcularon los precios, Empresas identificadas, Indicadores o comparación de precios, Resultado y Próximos pasos.

Reglas de redacción:
- Ir al punto, en frases cortas y profesionales. Nada de "cabe destacar", tríadas de relleno ni cierres motivacionales.
- Metodología en prosa corta, no en viñetas. Próximos pasos como lista numerada de acciones concretas.
- Nombrar los riesgos de precio por su nombre (qué cifra, por qué es incierta y qué hacer).
- Evitar rayas como separadores; usar punto o dos puntos.
- No poner cifras escritas dentro de textos: mostrarlas en celdas con fórmula para que no queden desactualizadas.

## 7. Técnica en Excel

- Editar con openpyxl (`keep_vba=True` en .xlsm). openpyxl conserva imágenes y vínculos externos.
- Recalcular una copia con LibreOffice e inyectar los valores calculados como caché en el archivo de openpyxl, con `fullCalcOnLoad`, para conservar el proyecto VBA original y que el archivo se vea bien en el celular.
- No usar TEXT() con separadores de miles (cambia según el idioma de Excel).
- Fuente y formatos de número iguales a los del formato original.

## 8. Verificación antes de entregar

- Recalculado sin errores nuevos (los que ya traía el original se reportan, no se tocan).
- Control de la tabla contractual en OK.
- Proyecto VBA idéntico (md5), imágenes presentes y hojas ocultas siguen ocultas.
- Revisión visual en PDF de las hojas nuevas.
- Comprobar a mano dos o tres precios unitarios.

## 9. Resumen para el cliente

Total con IVA, tabla corta de componentes, las dos o tres cifras que más pesan y deben confirmarse, correcciones hechas al formato y el siguiente paso (pedir cotizaciones a la lista corta).