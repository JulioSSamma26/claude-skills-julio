---
name: edicion-fotos
description: "Edita fotos con comandos cortos en vez de prompts largos: /identitylock (conservar cara o producto idénticos), /studioquality (luz y nitidez de estudio), /upscale (mejorar resolución o restaurar foto vieja), /cleanup (quitar distracciones y limpiar fondo), /fondoblanco (foto de catálogo), /lifestyle (producto en escena con mascota), /miniatura (portada de YouTube), y combinaciones como \"/cleanup + /studioquality\". Úsala cuando el usuario escriba uno de esos comandos o pida mejorar, limpiar, ampliar o retocar una foto de producto, de perfil o una miniatura. NO usar para crear diseños desde cero (usar Canva o canvas-design) ni para video (usar contenido o higgsfield)."
---

# Edición de fotos por comandos

Idea tomada de un reel de @academiaagentica ("comandos con / para editar fotos sin escribir prompts largos"), rehecha para las herramientas reales de Julio. Cada comando es un atajo a una receta fija.

## Comandos

| Comando | Qué hace | Herramienta preferida (si está conectada) |
|---|---|---|
| `/identitylock` | Fija la identidad: misma cara, rasgos, logo, color y forma del producto. Se combina con cualquier otro comando y siempre se aplica primero | Instrucción que acompaña a cualquier edición; usar la foto original como referencia |
| `/studioquality` | Luz suave de estudio, sombras limpias, nitidez, balance de blancos neutro, sin cambiar la composición | Higgsfield `generate_image` con la foto como referencia, o edición de imagen |
| `/upscale` | Más resolución y detalle; restaura fotos viejas o borrosas sin inventar rasgos | Higgsfield `upscale_image` |
| `/cleanup` | Quita objetos sobrantes, cables, manchas y personas del fondo; ordena la escena | Edición de imagen con máscara; si solo hay que quitar el fondo, `remove_background` |
| `/fondoblanco` | Fondo blanco puro (#FFFFFF), producto centrado y sombra suave: listo para Mercado Libre, Dropi o catálogo | Higgsfield `remove_background` + composición; Canva como alternativa |
| `/lifestyle` | Producto en una escena real: perro o gato usándolo, hogar o parque colombiano, luz natural | `generate_image` con la foto del producto como referencia y `/identitylock` |
| `/miniatura` | Portada de YouTube 1280×720 (16:9): sujeto grande, alto contraste, espacio para 2 a 4 palabras | `generate_image` o `reframe` a 16:9; el texto se agrega en Canva |

Los comandos se combinan de izquierda a derecha, por ejemplo `/cleanup + /studioquality + /upscale`. `/identitylock` va implícito siempre que haya una persona o un producto real.

## Proceso

1. **Revisar la entrada.** Confirmar que hay una foto adjunta. Si no la hay, pedirla. Anotar el formato de destino (Instagram 4:5, historia 9:16, catálogo 1:1, YouTube 16:9).
2. **Ver qué herramientas están conectadas.** Usar Higgsfield si está disponible. Si no, Canva. Si no hay ninguna, entregar el prompt exacto (con la receta del comando) para pegarlo en ChatGPT, Gemini o la herramienta que tenga el usuario, usando `optimizador-prompts`.
3. **Costo.** Higgsfield gasta créditos. Si la herramienta da un estimado (`estimate_image_cost`), decirlo antes de generar cuando sean varias imágenes. Para una sola edición, seguir sin preguntar.
4. **Ejecutar la receta** con `/identitylock` primero. Generar una sola versión salvo que se pidan varias.
5. **Verificar contra la original.** ¿Mismo producto, colores, logo y texto impreso? ¿Mismas proporciones de la cara? ¿Manos y patas bien formadas? Si algo cambió, repetir con una instrucción de identidad más estricta en vez de entregar.
6. **Entregar** la imagen, una línea con lo que se hizo y el formato. Si la imagen es para un anuncio, recordar que debe representar el producto real (sin funciones que no tiene).

## Reglas

- **Producto real:** en fotos de venta no se agregan funciones, accesorios ni colores que el producto no tiene. Mostrar algo distinto a lo que llega genera devoluciones en contraentrega.
- **Personas:** no cambiar la edad, el cuerpo ni la etnia de una persona real. En fotos de terceros, editar solo si el usuario tiene derecho a usarlas.
- **Niños** (canal infantil): no generar ni editar fotos realistas de niños reales para publicidad. Para miniaturas, usar ilustración o personajes.
- **Marcas ajenas:** no poner logos de otras marcas ni imitar el estilo de una marca concreta.
- Si piden "que parezca tomada con iPhone/Canon", es una instrucción de estilo, no de marca: se puede.
