---
name: growth-saas
description: "Palancas de crecimiento para productos de software o suscripción: precios y planes, reducción de churn y dunning, programas de referidos/afiliados, herramientas gratuitas como marketing, webinars y App Store Optimization. Úsala con \"cuánto cobro\", \"planes de precio\", \"cancelaciones\", \"churn\", \"programa de referidos\", \"webinar\", \"ASO\". Referidos y webinars sirven también para otros negocios. NO usar para dropshipping o el canal infantil salvo referidos/webinars."
---

# Growth para software y suscripciones

Skill fusionada: reúne 6 skills que antes competían entre sí. Este archivo solo enruta; el método completo de cada caso está en su módulo.

## Paso 1: elegir el módulo

| Módulo | Úsalo cuando | Leer |
|---|---|---|
| `pricing-strategy` | Estructura de planes, métrica de valor, página de precios, subidas de precio. **(solo SaaS/suscripción)** | `modulos/pricing-strategy/GUIA.md` |
| `churn-prevention` | Flujo de cancelación, ofertas de retención, pagos fallidos. **(solo SaaS/suscripción)** | `modulos/churn-prevention/GUIA.md` |
| `referral-program` | Diseñar o mejorar un programa de referidos o afiliados. | `modulos/referral-program/GUIA.md` |
| `free-tool-strategy` | Crear una herramienta gratis para captar leads o SEO. | `modulos/free-tool-strategy/GUIA.md` |
| `webinar-marketing` | Planear, promover y convertir con un webinar o evento virtual. | `modulos/webinar-marketing/GUIA.md` |
| `app-store-optimization` | Palabras clave, metadatos y visibilidad en App Store / Google Play. **(solo SaaS/suscripción)** | `modulos/app-store-optimization/GUIA.md` |

Si la petición toca dos módulos, empieza por el que produce el entregable y usa el segundo solo como apoyo. Si ninguno encaja, dilo y sugiere la skill correcta (ver `orquestador-skills`).

## Paso 2: ejecutar

Lee el `GUIA.md` del módulo y sigue su proceso y formato de salida. Anuncia en una línea el módulo usado, por ejemplo: "Uso growth-saas → `pricing-strategy`".

## Reglas comunes

- **Contexto primero:** si existe `.agents/product-marketing.md`, `.claude/product-marketing-context.md` o `.agents/marketing-context.md`, léelo antes de empezar. Si no existe y la tarea es de estrategia, sugiere una vez la skill `marketing-context`; para tareas pequeñas, sigue sin él.
- **Carga mínima:** lee solo `modulos/<modulo>/GUIA.md` del módulo elegido (máximo 2 módulos por tarea). Las rutas que aparecen dentro de cada guía (`references/`, `scripts/`, `assets/`, `templates/`) son relativas a la carpeta de ese módulo.
- **Idioma:** responde en el idioma del usuario (español por defecto) aunque la guía esté en inglés. Adapta ejemplos a Colombia/LatAm cuando aplique (COP, WhatsApp, Mercado Libre, Instagram).
- **Datos:** nunca inventes métricas, clientes ni resultados; si falta un número, déjalo como `{{dato}}` y pídelo.
- **Scripts de terceros** (revisados el 2026-11-21: solo librería estándar, sin exfiltración): ejecútalos con `python -I`, con datos ficticios o del proyecto de marketing, nunca con datos de Afinia. Los que aceptan URL solo descargan la URL que se les pasa.
- **Textos finales** que se van a publicar: pásalos por `humanizador` antes de entregarlos.

## Nombres antiguos (las guías pueden citarlos)

Si una guía dice "usa la skill X", traduce X a la skill actual:

| Nombre antiguo | Skill actual |
|---|---|
| page-cro, form-cro, popup-cro, signup-flow-cro, onboarding-cro, paywall-upgrade-cro | `cro` |
| seo-audit, schema-markup, site-architecture, programmatic-seo, competitor-alternatives, aeo, ai-seo, local-seo-manager | `seo` |
| social-content, social-media-manager, social-media-analyzer, x-twitter-growth | `redes-sociales` |
| copywriting, copy-editing | `copywriting` |
| cold-email, email-sequence | `email-marketing` |
| paid-ads, ad-creative | `anuncios` |
| content-strategy, content-production, content-creator, video-content-strategist | `contenido` |
| analytics-tracking, campaign-analytics, ab-test-setup | `analitica-marketing` |
| marketing-strategy-pmm, marketing-demand-acquisition, launch-strategy, marketing-ideas, marketing-psychology, business-name-fit, marketing-ops, ai-decision-authority | `estrategia-marketing` |
| pricing-strategy, churn-prevention, referral-program, free-tool-strategy, webinar-marketing, app-store-optimization | `growth-saas` |
| ads, ad-creative | `anuncios` |
| emails, cold-email, sms, prospecting, lead-magnets | `email-marketing` |
| social, influencer-marketing | `redes-sociales` |
| pricing, offers | `growth-saas` (precios) / `estrategia-marketing` (ofertas) |
| ai-seo, link-building, directory-submissions | `seo` |
| video, image | `contenido` / `optimizador-prompts` |
| conversion-tracking, analytics | `analitica-marketing` |
| marketing-plan, marketing-loops, public-relations, competitor-profiling, marketing-council | `estrategia-marketing` |
| content-humanizer, ai-tells | `humanizador` |
| prompt-engineer-toolkit | `optimizador-prompts` |

Una skill citada que no está en la tabla ni instalada (p. ej. `customer-research`, `sales-enablement`): sigue sin ella.
