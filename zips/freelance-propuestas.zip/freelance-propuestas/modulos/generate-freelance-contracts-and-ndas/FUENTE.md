Fuente: github.com/rondoflow/rondoflow (MIT), commit 71b6383. Descargado y escaneado el 2026-11-21. Texto original; solo SKILL.md se renombró a GUIA.md.
