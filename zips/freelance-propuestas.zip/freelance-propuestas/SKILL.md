---
name: freelance-propuestas
description: "Úsala para el trabajo freelance de automatización de Julio: escribir propuestas a la medida del cliente (alcance, entregables, cronograma, precio), cotizar en pesos colombianos y redactar contratos de servicios y acuerdos de confidencialidad (NDA) básicos. Úsala con \"hazme una propuesta\", \"cotiza este proyecto\", \"cuánto cobro por\", \"contrato para el cliente\", \"NDA\". NO usar para prospectar o escribir correos en frío (usar email-marketing) ni para precios de un producto de software (usar growth-saas)."
---

# Propuestas y contratos freelance

Fusión de 2 skills de rondoflow (MIT), adaptadas a Colombia.

| Necesidad | Módulo | Leer |
|---|---|---|
| Propuesta a la medida de un cliente | `generate-tailored-freelance-proposals` | `modulos/generate-tailored-freelance-proposals/GUIA.md` |
| Contrato de servicios o NDA | `generate-freelance-contracts-and-ndas` | `modulos/generate-freelance-contracts-and-ndas/GUIA.md` |

Guías en inglés; responde en español.

## Adaptación a Colombia

**Precio**
- En COP, con el IVA aparte si Julio es responsable de IVA. Si no lo es, aclararlo en la propuesta.
- Calcularlo desde horas estimadas × tarifa, más un margen por riesgo del 15–25 % según qué tan claro esté el alcance. Mostrar el precio por fases, no un solo número.
- Mencionar la retención en la fuente que suelen aplicar las empresas, para que el cliente no se sorprenda.

**Forma de pago:** anticipo (30–50 %) y pagos contra entregables aceptados. Nunca 100 % al final.

**Alcance**
- Lista cerrada de entregables y criterios de aceptación medibles.
- Qué queda **fuera** del alcance.
- Cuántas rondas de ajustes incluye.
- Soporte posterior: días y canal.

**Propiedad intelectual y datos:** quién es dueño del código y de los flujos; credenciales del cliente en sus propias cuentas, nunca en las de Julio; tratamiento de datos personales conforme a la Ley 1581 de 2012 (habeas data).

**Conflicto de interés**
- Ningún proyecto freelance puede usar información, código, horario ni equipos de Afinia.
- Si el cliente pertenece al sector eléctrico, Julio debe revisar antes su contrato laboral y las políticas de Grupo EPM.

**Contratos y NDA**
- Son borradores. Antes de firmar los revisa un abogado; esto **no es asesoría legal**.
- Ley aplicable: la colombiana. Jurisdicción: la ciudad que se pacte.
- Para contratos grandes, sugerir una cláusula de solución de controversias por conciliación.

**Redacción:** profesional y directa. Los textos finales pasan por `humanizador`.

**Entrega:** la propuesta como documento listo para enviar (tipo Docs, o docx si el cliente pide Word) y un resumen de 5 líneas para el correo de envío.
