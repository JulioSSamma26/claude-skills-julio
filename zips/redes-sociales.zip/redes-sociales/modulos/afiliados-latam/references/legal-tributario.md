# Marco legal y tributario básico (Colombia)

Orientación general consultada el 2026-11-21. No es asesoría legal ni tributaria. Para casos
concretos: abogado (consumo y datos) y **contador** (impuestos).

## 1. Divulgación de la publicidad

### Guía de buenas prácticas en la publicidad a través de influenciadores (SIC)

- Expedida por la Superintendencia de Industria y Comercio en 2020 (anuncio en inglés de la
  SIC fechado 20-nov-2020; la prensa ubica la expedición en octubre de 2020).
- **No es vinculante**: orienta sobre cómo aplicar las normas de consumo vigentes. La SIC
  advierte que el consumidor puede creer que una recomendación viene de experiencia personal
  cuando nace de un contrato con el anunciante.
- Recomendaciones citadas por prensa y firmas jurídicas: dejar claro desde el inicio que el
  contenido es publicidad, con etiquetas en español y tan visibles como el mensaje principal;
  el influenciador no debe aceptar ocultar la naturaleza comercial.
- El PDF oficial no se pudo abrir desde sic.gov.co en esta investigación. Verificar vigente en
  https://www.sic.gov.co (buscar "Guía de buenas prácticas en la publicidad a través de
  influenciadores").

Aplicación para Julio y sus embajadores:
- Como afiliado: "#Publicidad – Enlace de afiliado: recibo comisión si compras" al inicio.
- Como tienda: exigir la etiqueta en el contrato y revisar publicaciones al azar.
- En YouTube (canales para adultos): activar además "Incluye promoción pagada" en Studio
  (https://support.google.com/youtube/answer/154235).

### Ley 1480 de 2011 (Estatuto del Consumidor)

- Art. 30: prohíbe la publicidad engañosa; el anunciante responde por los perjuicios; el
  medio responde solidariamente solo con dolo o culpa grave (Corte Constitucional C-592/12).
- Art. 32: el anunciante solo se exonera por fuerza mayor, caso fortuito o adulteración o
  suplantación de la publicidad.
- Consecuencia práctica: si un embajador promete algo falso de un producto de Mascotas
  Seguras, el anunciante es la tienda. Usar lista de afirmaciones aprobadas.
- Art. 47 (retracto): en ventas a distancia, 5 días hábiles desde la entrega. El artículo fue
  modificado por la Ley 2439 de 2024 y hay pronunciamiento reciente de la Corte (C-192 de
  2026). Verificar el texto vigente antes de fijar la ventana de aprobación de comisiones.
- Texto: https://www.cancilleria.gov.co/sites/default/files/Normograma/docs/pdf/ley_1480_2011.pdf
  (puede no reflejar reformas; preferir versión con vigencias de Función Pública o Senado).

### Contenido infantil

- YouTube: el contenido de marca se retira de YouTube Kids; el programa de afiliados de
  YouTube Shopping excluye canales "made for kids"; en contenido "made for kids" se
  desactivan comentarios, notificaciones, tarjetas, pantallas finales y mercancía.
- COPPA (FTC, EE. UU.) se centra en la recopilación de datos de menores de 13 años; YouTube lo
  aplica globalmente a contenido marcado "made for kids".
- Decisión del módulo: **ni enlaces de afiliado ni promociones** en el canal infantil.

## 2. Datos personales: Ley 1581 de 2012

- Tratamiento con **autorización previa e informada** del titular, obtenida por un medio que
  se pueda consultar después (texto en Secretaría del Senado).
- Protección reforzada de datos de niños, niñas y adolescentes (art. 7). En este programa: no
  tratar datos de menores; embajadores solo mayores de edad.
- Deberes prácticos para Mascotas Seguras:
  - Política de tratamiento publicada (finalidades: gestionar pedidos, pagar comisiones,
    prevenir fraude; derechos de consulta, corrección y supresión; canal de contacto).
  - Formato de autorización para embajadores (y aviso en el formulario de compra).
  - Minimizar: nombre, cédula, teléfono, cuenta de pago. Guardar con acceso restringido.
  - No compartir datos de clientes con embajadores (el embajador ve id de pedido y estado, no
    nombre, teléfono ni dirección del cliente).
  - Si una app extranjera (Shopify, app de afiliados) guarda datos, eso es transferencia o
    transmisión internacional: revisarlo en la política. Verificar con abogado.
- RNBD: obligatorio para sociedades y entidades sin ánimo de lucro con activos superiores a
  100.000 UVT y personas jurídicas públicas (Decreto 090 de 2018). Las personas naturales no
  se inscriben, pero cumplen los demás deberes.
- Sanciones: la ley prevé multas, suspensión y cierre de operaciones de tratamiento. Monto
  máximo: verificar vigente en el art. 23 del texto oficial.

## 3. Tributario básico (consultar con contador)

Julio como afiliado:
- Las comisiones (Mercado Libre, Hotmart, Temu, Amazon) son ingresos de Julio. Suman para los
  topes de declarar renta, de responsabilidad de IVA y de obligación de facturar. **Consultar
  con contador.**
- Plataformas extranjeras: pueden pedir formularios fiscales. Amazon exige entrevista fiscal;
  sin W-8BEN con beneficio de tratado válido puede retener hasta 30% (ayuda de Amazon
  Associates). Si hay doble tributación o descuento tributario: **consultar con contador.**
- Mercado Libre Colombia pide RUT según guías de terceros; verificar en sus términos.

Mascotas Seguras pagando comisiones:
- El embajador entrega cuenta de cobro (si no está obligado a facturar) o factura electrónica.
  La tienda, según su situación, puede tener que emitir documento soporte de adquisiciones a
  no obligados a facturar. **Consultar con contador.**
- Retención en la fuente por comisiones: las fuentes consultadas citan 10% u 11% según la
  situación del beneficiario (art. 392 E.T. y Decreto 1625 de 2016) y una base mínima en UVT.
  Que la tienda sea o no agente de retención depende de su calidad (persona natural
  comerciante con ingresos o patrimonio superior a 30.000 UVT, art. 368-2, según fuentes
  secundarias). **Consultar con contador.**
- UVT 2026: $52.374 (Resolución DIAN 000238 de 2025, citada por Gerencie y Actualícese).
- Guardar soporte de cada pago: corte, pedidos incluidos, comisión, comprobante de
  transferencia y documento del embajador.

## Fuentes (consultadas 2026-11-21)

- SIC, anuncio de la guía de influenciadores: https://sedeelectronica.sic.gov.co/international-relations/sic-publishes-influencer-advertising-good-practices-guide
- Prensa sobre la guía: https://www.lafm.com.co/colombia/superindustria-emite-guia-de-buenas-practicas-para-influenciadores ; https://forbes.co/actualidad/sic-emite-lineamientos-para-influenciadores-y-sus-anunciantes
- YouTube, promoción pagada: https://support.google.com/youtube/answer/154235
- YouTube, contenido de marca: https://support.google.com/youtube/answer/17596007
- YouTube, "made for kids": https://support.google.com/youtube/answer/9632097
- YouTube Shopping afiliados: https://support.google.com/youtube/answer/13376398
- FTC, COPPA: https://www.ftc.gov/business-guidance/blog/2019/11/youtube-channel-owners-your-content-directed-children
- Ley 1480 de 2011: https://www.cancilleria.gov.co/sites/default/files/Normograma/docs/pdf/ley_1480_2011.pdf
- Corte Constitucional C-192/26 (retracto): https://www.corteconstitucional.gov.co/relatoria/2026/c-192-26.htm
- Retracto, prensa: https://www.asuntoslegales.com.co/consumidor/lo-que-debe-saber-para-ejercer-el-derecho-de-retracto-si-se-arrepiente-de-una-compra-3785580
- Ley 1581 de 2012: http://www.secretariasenado.gov.co/senado/basedoc/ley_1581_2012.html
- Decreto 090 de 2018: https://www.funcionpublica.gov.co/eva/gestornormativo/norma_pdf.php?i=85039
- Amazon Associates, entrevista fiscal: https://affiliate-program.amazon.com/help/node/topic/GYJB2LE2AB473W2L
- Retención 2026: https://www.gerencie.com/tabla-de-retencion-en-la-fuente-2026.html ; https://actualicese.com/estatutotributario/392-2/ ; https://actualicese.com/personas-naturales-retenedoras-2026/
