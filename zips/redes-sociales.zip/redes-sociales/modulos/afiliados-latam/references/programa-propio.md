# Programa de embajadores de Mascotas Seguras (contraentrega)

Diseño para una tienda que vende por Dropi con pago contraentrega. Los números en COP son
ejemplos para calcular, no datos de mercado.

## 1. Quiénes pueden ser embajadores

- Clientes satisfechos (programa "recomienda y gana").
- Creadores de contenido de mascotas en Instagram, TikTok, Facebook o LinkedIn.
- Paseadores, peluqueros caninos, veterinarias pequeñas, tiendas de barrio (venta asistida).
- Requisito: mayor de edad, con cédula. Nunca menores de edad ni contenido dirigido a niños.

## 2. Cálculo de la comisión (antes de anunciar un %)

Margen por pedido **entregado** =
precio de venta − costo del producto en Dropi − flete − comisiones de la plataforma
− descuento al cliente − (costo esperado de devoluciones repartido entre los entregados).

Costo esperado de devoluciones por pedido entregado ≈
(tasa de rechazo × flete de ida y vuelta) ÷ (1 − tasa de rechazo).

Regla: la comisión no debe pasar de una fracción del margen que Julio acepte perder por
adquirir un cliente. Ejemplo ilustrativo: si el margen por entregado es $20.000 COP, una
comisión de $6.000 (30% del margen) deja $14.000.

Opciones de estructura:
- **% fijo** sobre valor del producto sin flete (simple, recomendado al inicio).
- **Valor fijo por pedido entregado** (fácil de entender en WhatsApp: "ganas $5.000 por
  pedido entregado").
- **Escalones**: más % después de N pedidos entregados en el mes.
- **Bono de cliente**: el cliente recibe descuento con el código (motiva el uso del código y
  hace posible el seguimiento).

## 3. Ciclo de vida del pedido y de la comisión

| Estado del pedido (tienda/Dropi) | Estado de la comisión | Acción |
|---|---|---|
| Creado con código | Registrada | Nada que pagar |
| Confirmado por llamada/WhatsApp | Registrada | Confirmar datos reales del cliente |
| En tránsito | Registrada | — |
| Rechazado / devuelto / novedad no resuelta | Anulada | Notificar al embajador |
| Entregado y recaudado | Pendiente | Esperar ventana de retracto |
| Entregado + 5 días hábiles sin devolución | Aprobada | Entra al próximo corte |
| Liquidado | Pagada | Guardar comprobante |

Fuente del retracto de 5 días hábiles: Ley 1480 de 2011, art. 47 (ventas a distancia).
Verificar vigente en el texto de la ley.

Para confirmar entrega y recaudo, usar el estado del pedido en Dropi y el ingreso del
recaudo en la billetera; los plazos de abono de Dropi no se confirmaron en fuente oficial.

## 4. Seguimiento

1. **Código personal** por embajador (ej. `LAURA10`), configurado en la tienda y en el
   formulario contraentrega. Es el método principal porque funciona aunque el cliente
   termine el pedido por WhatsApp o llamada.
2. **Enlace con UTM** (`?utm_source=embajador&utm_campaign=laura`) o el enlace que genere la app.
3. **Pedidos por WhatsApp**: preguntar siempre "¿quién te recomendó o tienes código?" y
   anotarlo en el pedido antes de enviarlo a Dropi.
4. **Hoja de control** (Google Sheets o Excel) con columnas: fecha, id pedido tienda, id
   Dropi, código, embajador, valor producto, estado entrega, fecha entrega, fecha aprobación,
   comisión, corte, estado pago, observación de fraude.
5. Regla de atribución por escrito: gana el código usado en el pedido; si no hay código, el
   último enlace dentro de una ventana fija (por ejemplo 7 o 30 días, decisión de Julio).

## 5. Pago a embajadores

- Corte quincenal o mensual, con mínimo de pago (ej. $20.000 COP) para no hacer transferencias
  pequeñas; el saldo menor se acumula.
- Medios habituales: transferencia bancaria, Nequi o Daviplata a nombre del embajador (mismo
  titular que la cédula registrada).
- Soporte: cuenta de cobro si el embajador no está obligado a facturar, o factura electrónica
  si lo está; la tienda puede necesitar documento soporte y practicar retención en la fuente.
  **Consultar con contador** antes del primer pago.
- Enviar a cada embajador un resumen por corte: pedidos, estados, comisión aprobada y anulada.

## 6. Fraude típico y controles

| Fraude | Señal | Control |
|---|---|---|
| Autocompra con el propio código | Misma cédula, teléfono o dirección del embajador | Prohibido en contrato; cruce automático o manual; anular |
| Pedidos falsos que se rechazan | Tasa de rechazo del embajador muy superior a la de la tienda | Pagar solo entregados; pausa si supera el umbral acordado; cobrar fletes perdidos solo si el contrato lo dice |
| Pedidos entre conocidos para devolver luego | Devoluciones dentro del retracto | Pagar después de la ventana de retracto |
| Código filtrado a sitios de cupones | Usos desde ciudades o volúmenes raros | Tope de usos, cambio de código, cláusula de uso solo en canales propios |
| Puja por la marca en anuncios | Anuncios con "Mascotas Seguras" de terceros | Prohibido en contrato |
| Reseñas o testimonios falsos, promesas exageradas | Afirmaciones no aprobadas | Lista de afirmaciones permitidas; Ley 1480 art. 30 |
| Varias cuentas de la misma persona | Mismos datos de pago | Un embajador por cédula y cuenta de pago |
| Spam (grupos, mensajes masivos) | Quejas | Prohibido; terminación |

Recuperación: si un pedido pagado se devuelve después, descontar la comisión del siguiente
corte (cláusula de recuperación).

## 7. Herramientas

Sin plataforma: códigos manuales + hoja de control. Alcanza para empezar.

Si la tienda está en Shopify (confirmar con Julio; Dropi se conecta con Shopify y otras):

| App | Lo que dice su ficha | Contraentrega | Estado |
|---|---|---|---|
| COD Affiliates | Estados Generado, Confirmado, Recaudado; comisión solo en recaudados; enlaces, códigos y productos exclusivos; gratis; español | Sí, es su enfoque | Lanzada 21-may-2026, 0 reseñas: probar antes de confiar |
| WEBI COD Affiliate Marketing | Paga solo pedidos entregados y confirmados con estado de la transportadora; 2% por pedido pagado | Sí, según su ficha | Verificar vigente y si lee estados de Dropi |
| UpPromote | Códigos y enlaces, periodos de maduración, antifraude; gratis hasta US$3.000/mes en ventas referidas; Growth US$29,99/mes + 2% | No mencionada | 4,9 con 3.949 reseñas; probar con un pedido rechazado |
| GoAffPro | Estructuras de comisión configurables, multinivel | No mencionada | Verificar vigente |

Prueba obligatoria antes de lanzar: crear un pedido de prueba con código, marcarlo como
rechazado o cancelado y confirmar que la app **no** genera comisión aprobada.

## 8. Plantilla de acuerdo simple de embajador (borrador, revisar con abogado)

```
ACUERDO DE EMBAJADOR – MASCOTAS SEGURAS

Partes: [Nombre de Julio / razón social], en adelante LA TIENDA, y [nombre], C.C. [número],
en adelante EL EMBAJADOR.

1. Objeto. EL EMBAJADOR recomienda productos de LA TIENDA usando el código [CÓDIGO] o el
   enlace asignado. No hay relación laboral ni exclusividad.
2. Comisión. [X]% del valor del producto sin flete ni descuentos, o $[valor] por pedido.
   Se gana solo cuando el pedido es entregado, recaudado y pasan 5 días hábiles sin
   devolución ni retracto. Pedidos rechazados, devueltos, cancelados o fraudulentos no
   generan comisión.
3. Pago. Corte [quincenal/mensual], mínimo $[valor], por transferencia a cuenta a nombre del
   EMBAJADOR, contra [cuenta de cobro/factura]. Se aplican las retenciones de ley.
4. Recuperación. Si un pedido pagado se devuelve después, LA TIENDA descuenta esa comisión
   del siguiente pago.
5. Publicidad. EL EMBAJADOR indica siempre que es publicidad (#Publicidad o texto
   equivalente) al inicio del contenido, conforme a la guía de influenciadores de la SIC, y
   usa solo afirmaciones aprobadas por LA TIENDA. No promete resultados ni dirige contenido a
   menores de edad.
6. Prohibiciones. Autocompras, pedidos falsos, compartir el código en sitios de cupones,
   anuncios pagados con la marca de LA TIENDA, reseñas falsas y spam. Incumplir permite
   anular comisiones y terminar el acuerdo.
7. Datos personales. LA TIENDA trata los datos del EMBAJADOR para pagos y control de fraude
   según su política de tratamiento (Ley 1581 de 2012). EL EMBAJADOR no recoge ni guarda
   datos de clientes por fuera del proceso de LA TIENDA.
8. Duración y terminación. Indefinido; cualquiera lo termina con aviso escrito de [N] días.
   Las comisiones aprobadas antes de terminar se pagan en el siguiente corte.

Firmas y fecha. Autorización de tratamiento de datos adjunta.
```
