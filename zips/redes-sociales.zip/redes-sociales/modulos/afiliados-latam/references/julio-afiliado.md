# Julio como afiliado: programas, requisitos y pagos

Investigado el 2026-11-21. Cada dato lleva su fuente. "Verificar vigente" significa que no se
pudo leer la página oficial completa (captcha, inicio de sesión o página vacía) o que el dato
viene de un tercero.

## Mercado Libre Colombia: "Afiliados y Creadores"

- **Existe para Colombia.** Página oficial: https://www.mercadolibre.com.co/l/afiliados. El
  extracto del buscador dice: compartir enlaces de productos en redes y ganar "hasta 10% por
  venta", con enlace a los Términos y condiciones de Afiliados y Creadores.
- La página pidió captcha al consultarla de forma automática; **no se resolvió** (regla de
  seguridad). Verificar vigente leyéndola en el navegador.
- Requisitos según guías de terceros (no oficiales): RUT actualizado, municipio registrado,
  cuenta bancaria y cuenta de Mercado Pago; disponible solo en algunos municipios.
  Verificar vigente en https://www.mercadolibre.com.co/l/afiliados
- Venta directa (el producto enlazado) frente a indirecta (otro producto): una guía de terceros
  dice que la indirecta paga la mitad. Verificar en los términos oficiales.
- Otros países tienen otros topes (México, Chile y Argentina publican cifras distintas). No
  trasladar porcentajes de otro país a Colombia.
- En Chile, las campañas para creadores exigen más de 10.000 seguidores en Instagram o TikTok
  (https://www.mercadolibre.cl/l/preguntas-frecuentes-para-creadores). Para Colombia: verificar.
- Pago: a la cuenta de Mercado Pago según terceros; plazos y mínimos: verificar en términos.

Pasos para Julio (él los hace): 1) leer términos CO; 2) confirmar que su municipio está
habilitado; 3) tener RUT y Mercado Pago al día; 4) generar enlaces solo de productos que la
tienda no vende; 5) etiquetar como publicidad.

## Amazon Associates

- **No hay programa de Amazon para Colombia.** La página de programas internacionales lista
  Estados Unidos, Canadá, México, Brasil, Reino Unido, Alemania, Francia, España, Italia,
  Países Bajos, Suecia, Polonia, EAU, Arabia Saudita, India, Japón, Singapur, China y
  Australia (https://affiliate-program.amazon.com/help/node/topic/GCE3F2NCVZLDFM6A).
- Si un residente en Colombia puede unirse al programa de EE. UU.: **no confirmado** en fuente
  oficial. Verificar vigente en https://affiliate-program.amazon.com/help/node
- Formas de pago: transferencia bancaria, tarjeta de regalo o cheque. La transferencia
  internacional cubre 52 países y Colombia **no** aparece en la lista consultada
  (https://affiliate-program.amazon.com/help/node/topic/G8VUMS6GTBCR9RGV).
- Mínimos en el programa de EE. UU. según páginas de ayuda: US$10 para tarjeta de regalo y
  depósito, US$100 para cheque; pago unos 60 días después del cierre del mes. Verificar vigente
  en https://affiliate-program.amazon.com/help/node/topic/GP8Z3AZ27ZFHTEUL
- Impuestos de EE. UU.: entrevista fiscal obligatoria; sin W-8BEN válido Amazon puede retener
  hasta 30% (https://affiliate-program.amazon.com/help/node/topic/GYJB2LE2AB473W2L).
  **Consultar con contador.**
- Comisión por categoría (mascotas, juguetes): está en la tabla de Associates Central, que
  pide inicio de sesión. No se cita porcentaje. Verificar vigente dentro de Associates Central.
- Valor real para Julio: bajo. Su público compra en COP y con contraentrega.

## Hotmart (productos digitales)

- Útil solo para recomendar cursos o ebooks (por ejemplo, adiestramiento o cuidado de mascotas).
- La comisión la fija el productor, entre 0% y 80% del valor, calculada después de la tarifa de
  Hotmart (https://help.hotmart.com/es/article/215828158 y
  https://help.hotmart.com/es/article/360011780352).
- Atribución: el productor elige último clic o varios clics; la cookie dura 60, 90, 180 días o
  indefinida según el producto (https://help.hotmart.com/es/article/36806399753485).
- Retiro para residentes en Colombia, según la Ayuda de Hotmart (extractos del buscador, la
  página no cargó completa): en COP o USD; la cuenta debe estar a nombre del mismo titular y
  tipo de persona; verificación hasta 5 días hábiles; transferencia automática mensual o retiro
  manual; vía Payoneer mínimo US$50 y máximo US$5.000; no acepta cuentas Wise. Tarjeta Hotmart
  virtual para usuarios con domicilio fiscal en Colombia, habilitada de forma gradual.
  Verificar vigente en https://help.hotmart.com/es/article/216440207 y
  https://help.hotmart.com/es/article/23867226765709
- Tarifas de retiro en COP: no encontradas. Verificar.

## Temu Afiliados

- Tiene páginas de afiliados por país (por ejemplo Uruguay y México) con comisión "hasta 30%" y
  cookie de 30 días. Una guía de terceros incluye a Colombia entre los países aprobados.
- La página de Colombia no cargó al consultarla. Verificar vigente en
  https://www.temu.com/co/affiliate_recruit.html (requisitos, pago y comisiones para CO).
- Riesgo de marca: Temu compite en precio con accesorios para mascotas; no mezclar con la tienda.

## Dropi y otras plataformas de dropshipping

- No se encontró un programa oficial de referidos de Dropi con términos públicos.
- Blogs de mentores dicen que registrarse con el enlace de un mentor quita una comisión de
  2% a 5% por venta, y que el pago a la billetera llega 2 a 7 días hábiles después de la
  entrega. Estos blogs venden ese mismo enlace (conflicto de interés). Verificar en dropi.co o
  con soporte de Dropi antes de citarlo.

## Falabella

- Lanzó "Creators F" (afiliados) según prensa de retail sobre Chile. Disponibilidad en Colombia
  no confirmada. Verificar en falabella.com.co.

## YouTube Shopping (programa de afiliados de YouTube)

- Requisitos: estar en el Programa de Socios de YouTube, no ser canal de música, audiencia **no**
  configurada como "made for kids" ni muchos videos así, y residir en uno de 18 países.
  Colombia **no** está en la lista (https://support.google.com/youtube/answer/13376398).
- Conclusión: no aplica ni al canal infantil ni a Colombia hoy.

## LinkedIn

- Es el canal natural para Julio como afiliado o para la tienda. No se verificaron en esta
  investigación las reglas de LinkedIn sobre enlaces de afiliado. Verificar vigente en las
  Políticas de la Comunidad Profesional de LinkedIn antes de publicar en volumen.
- Siempre etiquetar la publicación como publicidad (guía SIC).
