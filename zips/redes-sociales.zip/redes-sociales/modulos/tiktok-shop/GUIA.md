---
name: tiktok-shop
description: "Vender por TikTok desde Colombia para \"Mascotas Seguras\" (accesorios para mascotas, Dropi, contraentrega, WhatsApp, COP). TikTok Shop no opera en Colombia a nov-2026: enseña contenido orgánico, tráfico a WhatsApp, Spark Ads y anuncios de mensajes, creadores locales, medición por pedidos entregados, divulgación de publicidad, etiqueta de IA y guía SIC."
---

**Estado a 2026-11-21: TikTok Shop NO está disponible en Colombia.** La ayuda oficial de TikTok for Business ("Acerca de TikTok Shop y Showcase", actualizada en junio de 2026) lista 15 mercados y Colombia no figura; en LatAm solo están México (desde el 6-feb-2025) y Brasil (desde el 8-may-2025). No hay anuncio oficial de fecha para Colombia. Ver `references/disponibilidad-latam.md`.

> No confíes en las páginas `tiktok.com/discover/...` que dicen "TikTok Shop ya está en Colombia": son resúmenes automáticos y se contradicen entre sí. Antes de cambiar la estrategia, vuelve a revisar la ayuda oficial y el newsroom.

## Cuándo usar este módulo

- Julio quiere vender accesorios de Mascotas Seguras con TikTok: videos, perfil, anuncios o creadores.
- Hay que decidir entre contenido orgánico, Spark Ads o anuncios de mensajes a WhatsApp, o cómo trabajar con un creador.
- Hay que revisar si un video o una colaboración cumple las reglas de TikTok y la guía de la SIC.
- Alguien pregunta "¿ya llegó TikTok Shop a Colombia?". Responde con el estado de arriba y vuelve a verificarlo si la fecha de consulta tiene más de 60 días.

No usar para: catálogo y precios en Dropi, guiones largos de otras redes (usar el módulo de Instagram) ni para preguntas legales que necesitan abogado.

## Modelo de venta (mientras no haya Shop)

```
Video TikTok (orgánico o Spark Ad)
   → CTA: "escríbenos por WhatsApp" / enlace del perfil / DM
      → WhatsApp: confirmar talla, ciudad y dirección, y la contraentrega
         → pedido en Dropi → despacho → ENTREGADO (esta es la venta real)
```

La conversión ocurre fuera de TikTok. Por eso cada video necesita un CTA claro y un código para saber de qué video llegó el cliente (ver Medición).

## 1. Perfil y cuenta

1. Usa una **cuenta de empresa** (Business) a nombre de Mascotas Seguras.
2. **Enlace en la bio**: TikTok exige al menos 1.000 seguidores o una cuenta de empresa verificada (*verificar* si el registro de empresa ya está habilitado para Colombia). Mientras tanto, pon el WhatsApp en el texto de la bio y responde los DM.
3. En la bio, en una línea: qué vendes, envíos a toda Colombia, pago contraentrega y el WhatsApp.
4. Fija 3 videos arriba: el más vendido, una prueba social (cliente real) y otro que explique cómo pedir y pagar contraentrega.

## 2. Contenido orgánico que vende accesorios para mascotas

Formatos que funcionan (detalle, ganchos y guiones en `references/contenido-organico-mascotas.md`):

| Formato | Ejemplo Mascotas Seguras | Por qué vende |
|---|---|---|
| Problema → solución | El perro jala la correa → arnés antitirones en 10 s | Muestra el dolor y la solución en un solo plano |
| Antes / después | Sale corriendo al abrir la puerta → placa con GPS o arnés con reflectivo | El cambio se ve sin leer nada |
| Prueba en vivo | "¿Aguanta?": tirón al arnés o lavado del collar | Genera credibilidad física |
| Unboxing del cliente | Video del cliente al recibir el pedido contraentrega | Prueba social y confianza en el pago |
| POV de la mascota | "POV: mi humano por fin me compró…" | Humor y altas tasas de vistas completas |
| Respuesta a comentario | "¿Sirve para gatos?", contestado con video | El algoritmo lo premia y resuelve la objeción |

Reglas: gancho en los primeros 2 segundos, producto visible antes del segundo 3, vertical 9:16, subtítulos, un solo CTA. No maltrates ni estreses al animal para el video: es una infracción de las Normas de la Comunidad y destruye la confianza.

## 3. Llevar el tráfico a WhatsApp

- **CTA único por video**: "Escríbenos al WhatsApp de la bio y pídelo contraentrega".
- **Enlace `wa.me` con texto prellenado** por video o por campaña (ej. `...?text=Hola,%20vi%20el%20video%20ARNES01`). Así sabes de qué video llegó el cliente.
- **DM**: deja una respuesta rápida que pase a WhatsApp con el mismo código.
- **Comentarios**: responde las dudas de talla y precio. Si una pregunta se repite, contéstala con un video.

## 4. TikTok Ads (cuando un video orgánico ya funcionó)

Detalle y paso a paso en `references/ads-y-creadores.md`.

- **Spark Ads**: promocionan un video orgánico propio o de un creador con su autorización. Las interacciones se suman al post original. Úsalos con el video que ya ganó en orgánico.
- **Anuncios de mensajes (Instant Messaging Ads)**: objetivo *Generación de clientes potenciales*, con destino WhatsApp. Exigen un número de **WhatsApp Business API** exclusivo. La optimización recomendada es *Conversaciones*; la alternativa es *Clics*. *Verificar* que estén disponibles para cuentas de Colombia en el Administrador de anuncios.
- **Tráfico o conversiones a la web**: solo si la tienda tiene Pixel o Events API y un checkout que funcione.
- Prohibido en anuncios: vender o regalar animales vivos (política "Animals and Environment"). Accesorios sí.
- No gastes nada sin un presupuesto aprobado por Julio. Empieza con prueba pequeña, 3-5 creativos y corte a 7 días.

## 5. Creadores locales

- **Modelos**: envío del producto a cambio de video, tarifa fija, o comisión por pedido **entregado** con un código único.
- Microcreadores (5k-50k seguidores) de mascotas en Colombia, con audiencia en las ciudades donde Dropi entrega bien.
- Brief corto: producto, beneficio, 1 gancho sugerido, CTA con código y divulgación obligatoria.
- Pide la autorización de Spark Ads en el acuerdo para poder pautar el video.

## 6. Cumplimiento (siempre)

Detalle en `references/cumplimiento.md`.

1. **Divulgación en TikTok**: activa *Divulgar contenido comercial*. En tus propios videos marca **Tu marca** (aparece "Contenido promocional"). El creador marca **Contenido de marca** (aparece "Colaboración pagada"). Sin la etiqueta, TikTok puede reducir el alcance o sancionar la cuenta.
2. **IA**: si el video tiene imagen, audio o voz realista hecha o muy editada con IA (perro generado, voz clonada), pon la etiqueta de contenido generado por IA. En anuncios, marca "Este anuncio contiene contenido generado por IA". Si es un Spark Ad, la etiqueta va en el post orgánico.
3. **SIC, Guía de buenas prácticas en la publicidad a través de influenciadores (2020)**: usa "#publicidad @mascotasseguras" o "Patrocinado por @mascotasseguras", visible desde el inicio. En video la divulgación se mantiene todo el video y en LIVE se repite. Regalar el producto también es pago. Términos como #sp, #collab o #gracias **no bastan**. El anunciante (Julio) responde por la publicidad engañosa (Ley 1480 de 2011, art. 30).
4. **Afirmaciones**: nada de "100 % irrompible" o "evita que se pierda" sin pruebas. Di lo que el producto hace, con medidas reales.

## 7. Medición: pedidos entregados, no creados

- Métrica principal: **costo por pedido entregado** = gasto (anuncios + creadores + producto regalado) ÷ pedidos con estado *Entregado* en Dropi.
- Registra por código (video o creador): conversaciones → pedidos creados → despachados → entregados → devueltos.
- Una campaña con muchos pedidos creados y entrega baja pierde plata con la contraentrega (flete de ida y vuelta).
- Si usas la web, envía la compra a TikTok solo al confirmarse la entrega (eventos offline / Events API). *Verificar* la integración con Dropi.
- Plantilla y fórmulas en `references/medicion-y-preparacion-shop.md`.

## 8. Qué preparar para cuando llegue TikTok Shop

- Catálogo con fotos propias, medidas, tallas y precios en COP. Ten claro el margen para absorber una comisión (en México, el Seller Center ofrece 0 % de comisión los primeros 60 días; la tarifa para Colombia será otra, *verificar* al lanzamiento).
- Datos de la empresa listos: RUT, cuenta bancaria a nombre del negocio y cámara de comercio si aplica.
- Lista de creadores con quienes ya trabajaste: serán tus primeros afiliados.
- Revisar si Dropi permite despachar pedidos de TikTok Shop o si TikTok exige su propia logística.
- Cuando se anuncie, lee el anuncio oficial del newsroom y los requisitos del Seller Center de Colombia antes de registrarte.

## Lista de verificación antes de publicar

- [ ] Gancho en ≤2 s, producto visible en ≤3 s, subtítulos
- [ ] CTA único con código de seguimiento
- [ ] Divulgación comercial activada (Tu marca / Contenido de marca)
- [ ] Etiqueta de IA si hay imagen o voz realista sintética
- [ ] #publicidad visible si hay creador pagado o con producto regalado
- [ ] Sin afirmaciones que no puedas probar y sin animales en riesgo

## Fuentes (consultadas el 2026-11-21)

- TikTok for Business, ayuda: "Acerca de TikTok Shop y Showcase" (act. jun-2026): https://ads.tiktok.com/help/article/tiktok-shopping-and-showcase?lang=es
- TikTok Newsroom, "TikTok Shop llega a México" (6-feb-2025): https://newsroom.tiktok.com/tiktok-shop-llega-a-mexico?lang=es-419
- TikTok Newsroom, "TikTok Shop chega ao Brasil" (8-may-2025): https://newsroom.tiktok.com/tiktok-shop-chega-ao-brasil?lang=pt-BR
- DPL, "TikTok Shop Available Countries 2026" (act. 5-nov-2026): https://dpl.company/countries-with-access-to-tiktok-shop-seller-center/
- TikTok Seller Center México (incentivos, 0 % los primeros 60 días): https://seller.tiktok.com/mx
- TikTok Support, "Promoting a brand, product, or service": https://support.tiktok.com/en/business-and-creator/creator-and-business-accounts/promoting-a-brand-product-or-service
- TikTok Support, requisitos para el contenido generado por IA: https://support.tiktok.com/en/using-tiktok/creating-videos/ai-generated-content
- TikTok Ads, disclaimers de anuncios (IA): https://ads.tiktok.com/resources/help/article/add-disclaimers-to-ads
- TikTok Ads, Spark Ads (act. jun-2026): https://ads.tiktok.com/resources/help/article/spark-ads
- TikTok Ads, Instant Messaging Ads (act. oct-2025): https://ads.tiktok.com/resources/help/article/how-to-set-up-tiktok-instant-messaging-ads
- TikTok Ads, política "Animals and Environment": https://ads.tiktok.com/resources/help/article/tiktok-ads-policy-animals-and-environment
- TikTok Support, enlace en el perfil: https://support.tiktok.com/en/getting-started/setting-up-your-profile/linking-another-social-media-account
- SIC, Guía de buenas prácticas en la publicidad a través de influenciadores (expedida el 3-ago-2020): https://sedeelectronica.sic.gov.co/transparencia/normativa/guia-de-buenas-practicas-en-la-publicidad-traves-de-influenciadores
- Más fuentes en cada archivo de `references/`.
