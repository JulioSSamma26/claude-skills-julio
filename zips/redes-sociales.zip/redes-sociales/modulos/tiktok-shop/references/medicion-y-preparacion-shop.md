# Medición por pedidos entregados y preparación para TikTok Shop

## Por qué medir entregados y no creados

Con contraentrega, un pedido creado no es una venta. Si el cliente no recibe, pagas el flete de ida y vuelta y no cobras nada. Un video que genera muchos pedidos de baja calidad parece exitoso y en realidad pierde plata.

## Hoja de control (una fila por código de video o creador)

| Columna | Origen |
|---|---|
| Código (ARNES01, CREADOR01…) | Texto prellenado de `wa.me` o lo que el cliente menciona |
| Vistas | Analíticas de TikTok |
| Conversaciones de WhatsApp | Conteo de chats con el código |
| Pedidos creados | Dropi |
| Pedidos entregados | Dropi (estado *Entregado*) |
| Devueltos / no recibidos | Dropi |
| Gasto | Anuncios + pago al creador + costo del producto regalado + envío del regalo |
| Ganancia por entregado | Precio − costo del proveedor − flete − comisión de recaudo (según Dropi) |

## Fórmulas

- **Tasa de entrega** = entregados ÷ creados
- **Costo por pedido entregado (CPE)** = gasto ÷ entregados
- **Costo real de devoluciones** = devueltos × flete de ida y vuelta (*verificar* la tarifa con Dropi)
- **Utilidad de la campaña** = (entregados × ganancia por entregado) − gasto − costo de devoluciones
- Regla: escala solo si la utilidad de la campaña es mayor que 0 con al menos 7 días de datos.

## Reducir pedidos que no se entregan

- Confirma por WhatsApp el nombre, la dirección completa y el teléfono antes de crear el pedido en Dropi.
- Para pedidos de valor alto o ciudades con historial malo, envía un segundo mensaje de confirmación el día del despacho.
- Corta los creativos que traen muchos chats y pocas confirmaciones.

## Enviar la señal correcta a TikTok (opcional, si hay web)

- Pixel y Events API para los eventos de la web.
- **Eventos offline** (Events Manager → conjunto de eventos offline, o Events API): permiten subir compras ocurridas fuera de la web. Úsalo para reportar como compra **solo los pedidos entregados**.
- *Verificar* si Dropi o la plataforma de la tienda tiene integración nativa. Si no, haz una carga manual periódica en CSV.
- Fuentes: https://ads.tiktok.com/resources/help/article/about-offline-conversions?lang=en, https://ads.tiktok.com/resources/help/article/about-events-api-for-offline?lang=en

## Preparación para cuando TikTok Shop llegue a Colombia

Lo que se sabe de México sirve de referencia, no de regla para Colombia:

- México (lanzamiento 6-feb-2025): LIVE Shopping, programa de afiliados con comisiones para creadores y pagos por terceros (TikTok Newsroom).
- El Seller Center de México ofrece incentivos para vendedores nuevos y "0 % de comisión durante tus primeros 60 días" (https://seller.tiktok.com/mx, consulta 2026-11-21). Las comisiones después de ese periodo y las de Colombia: **verificar** en el Seller Center del país cuando abra.

Lista de preparación:

1. **Catálogo**: fotos y videos propios (no los del proveedor), medidas, tallas, materiales y precio en COP.
2. **Márgenes**: calcula hoy el precio mínimo que aguanta una comisión de plataforma y una comisión de afiliado sin perder.
3. **Documentos**: RUT, cuenta bancaria del negocio y cámara de comercio si aplica. Los requisitos exactos de Colombia se sabrán al lanzamiento.
4. **Logística**: pregunta a Dropi si planea integrarse con TikTok Shop. En otros mercados TikTok exige tiempos de despacho y seguimiento. *Verificar* si aceptará contraentrega en Colombia.
5. **Afiliados**: los creadores con los que ya hay historial de entregados serán los primeros afiliados.
6. **LIVE**: practica desde ya LIVEs con CTA a WhatsApp, así el formato estará probado.
7. **Alerta**: revisa cada mes la ayuda oficial y el newsroom (ver `disponibilidad-latam.md`).
