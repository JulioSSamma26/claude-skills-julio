# Disponibilidad de TikTok Shop en LatAm (consulta: 2026-11-21)

## Conclusión

TikTok Shop **no opera en Colombia** al 2026-11-21. En América Latina solo opera en **México** y **Brasil**. Ninguna fuente oficial anuncia una fecha para Colombia.

## Evidencia

| País | Estado | Fuente y fecha |
|---|---|---|
| México | Disponible desde el 6-feb-2025 | TikTok Newsroom, "TikTok Shop llega a México": https://newsroom.tiktok.com/tiktok-shop-llega-a-mexico?lang=es-419 |
| Brasil | Disponible desde el 8-may-2025 | TikTok Newsroom, "TikTok Shop chega ao Brasil": https://newsroom.tiktok.com/tiktok-shop-chega-ao-brasil?lang=pt-BR |
| Colombia | No disponible | Ayuda oficial TikTok for Business (act. jun-2026): lista Brasil, España, EE. UU., Filipinas, Francia, Indonesia, Irlanda, Italia, Japón, Malasia, México, Reino Unido, Singapur, Tailandia y Vietnam. Colombia no aparece. https://ads.tiktok.com/help/article/tiktok-shopping-and-showcase?lang=es |
| Colombia | No disponible | DPL (act. 5-nov-2026, cotejado con los portales del Seller Center): en las Américas, solo EE. UU., México y Brasil. https://dpl.company/countries-with-access-to-tiktok-shop-seller-center/ |
| Colombia, Argentina, Chile | No disponible | Marpany (sep-2026): "no aparecen en ninguna lista oficial… TikTok no ha anunciado fechas". https://marpany.com/es/blog/tiktok-shop-espana-mexico |
| Perú | No disponible al 21-oct-2026 | AVII Perú: https://aviiperu.com/articulos/tiktok-shop-peru/ |
| Chile | No disponible, sin fecha oficial | El Observatodo (20-nov-2026), que cita las Normas de la Comunidad: https://www.elobservatodo.cl/noticia/economia/vendes-por-tiktok-las-nuevas-normas-que-deben-cumplir-los-emprendedores-para-evitar |

Nota: la ayuda oficial (act. jun-2026) no incluye los mercados europeos que se sumaron después, como Austria, Bélgica, Países Bajos, Polonia y Portugal (TikTok Newsroom, "TikTok Shop Expands Across Europe", 28-may-2026). Puede tardar en actualizarse, así que contrasta siempre con el newsroom.

## Señales de contexto en Colombia (no implican que haya Shop)

- Noticias RCN (abr-2026): TikTok pidió licencias financieras. No se esperaban créditos de TikTok en Colombia en el primer semestre de 2026. https://www.noticiasrcn.com/economia/tiktok-prepara-su-propia-billetera-digital-y-microcreditos-para-millones-de-clientes-1009449
- Forbes Colombia: los clientes empresariales de TikTok en Colombia crecieron 53 %. https://forbes.co/tecnologia/tiktok-crece-en-un-53-sus-clientes-en-colombia-consolidando-al-pais-como-hub-para-la-region-andina

## Fuentes que NO se deben usar

- Las páginas `tiktok.com/discover/...` (por ejemplo, "tiktok-shop-cuando-llega-a-colombia") son agregadores automáticos: una dice que "ya está disponible" y otra que "aún no está disponible".
- Las páginas `shop.tiktok.com/us/k/tiktok-shop-en-colombia` son de SEO del mercado de EE. UU.
- Blogs de anuncios que listan a Colombia como disponible sin citar una fuente oficial (ej. una guía de Ecomdy).

## Cómo volver a verificar (sin iniciar sesión)

1. Revisa la lista de países en la ayuda oficial "Acerca de TikTok Shop y Showcase".
2. Busca en newsroom.tiktok.com "TikTok Shop Colombia".
3. Revisa si existe `seller.tiktok.com/co` o una opción de Colombia en el selector de país del Seller Center.
4. Anota la fecha de consulta en GUIA.md y en este archivo.
