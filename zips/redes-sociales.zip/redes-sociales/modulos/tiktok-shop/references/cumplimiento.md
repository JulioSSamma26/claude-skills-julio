# Cumplimiento: divulgación comercial, IA y guía SIC

## 1. TikTok: divulgación de contenido comercial

Fuente: TikTok Support, "Promoting a brand, product, or service", y TikTok Ads, "How to turn on the Commercial Content Disclosure setting".

- Todo contenido que promocione una marca, un producto o un servicio debe tener activado el ajuste de **divulgación de contenido** (*Divulgar contenido del post*, o *Divulgar contenido del LIVE* en vivo). Esto incluye promocionar tu propio negocio.
- Opciones:
  - **Tu marca**: los videos de Mascotas Seguras en su propia cuenta. Aparece la etiqueta **Contenido promocional**.
  - **Contenido de marca**: el creador que promociona a Mascotas Seguras. Aparece **Colaboración pagada** y puede etiquetar al socio de marca (la autorización dura 60 días por defecto).
- Después de publicar, la etiqueta no se puede cambiar.
- Consecuencias de no divulgar: según prensa de nov-2026 que cita las Normas de la Comunidad, menos distribución en "Para ti", avisos que hay que atender en 24 h, pérdida de funciones como LIVE y, en casos graves o repetidos, inhabilitación de la cuenta (El Observatodo, 20-nov-2026; *verificar* en las Normas de la Comunidad vigentes).

## 2. TikTok: contenido hecho con IA

Fuentes: TikTok Support, requisitos para el contenido generado por IA; página in-app "AI-generated content"; TikTok Ads, disclaimers.

- **Orgánico**: es **obligatorio** etiquetar el contenido realista (imagen, audio o video) completamente generado o muy editado con IA. Para lo demás es recomendable.
  - "Etiquetado por el creador como generado por IA": lo pone el creador al publicar. No afecta la distribución y no se puede quitar después.
  - "Generado por IA": TikTok lo pone automáticamente si detecta efectos de IA de TikTok o credenciales de contenido C2PA.
  - Si solo usas efectos de TikTok, no hace falta la etiqueta (se muestra el nombre del efecto).
- **Anuncios**: el Administrador de anuncios exige marcar "Este anuncio contiene contenido generado por IA" cuando aplica. En Spark Ads la etiqueta va en el post orgánico.
- Ejemplos en Mascotas Seguras: un perro generado con IA usando el arnés, una voz clonada en el video o fotos de producto "mejoradas" que cambian el aspecto real → **etiquetar**. Corregir color o recortar → no hace falta.
- Por protección al consumidor, nunca muestres con IA un producto distinto al que se entrega.

## 3. SIC: Guía de buenas prácticas en la publicidad a través de influenciadores

- Emisor: Superintendencia de Industria y Comercio (Delegatura de Protección al Consumidor). La sede electrónica registra la expedición el 3-ago-2020.
- Naturaleza: es "derecho flexible" (no es una norma nueva), pero interpreta la **Ley 1480 de 2011** (Estatuto del Consumidor), que sí es obligatoria.
- Página oficial: https://sedeelectronica.sic.gov.co/transparencia/normativa/guia-de-buenas-practicas-en-la-publicidad-traves-de-influenciadores
- PDF oficial: https://sedeelectronica.sic.gov.co/sites/default/files/normatividad/112020/GU%C3%8DA%20DE%20BUENAS%20PR%C3%81CTICAS%20EN%20LA%20PUBLICIDAD%20A%20TRAV%C3%89S%20DE%20INFLUENCIADORES%20005.pdf

### Qué pide en la práctica

- **Etiquetas recomendadas**: "#publicidad @marca", "@marca #publicidad", "#avisopromocionado por @marca", "#Patrocinadopor @marca", o frases como "contenido publicitario" y "patrocinado por".
- **Etiquetas insuficientes o confusas**: #sp, #collab, #gracias, #patrocinio, "en asociación con", "gracias a [marca]", "esto es posible por", o decir solo que se es "embajador".
- **Ubicación**: en español, visible desde el primer momento, tan legible como el mensaje principal y no escondida entre otros hashtags.
- **Video**: la divulgación se ve o se oye durante toda la pieza. **En vivo**: se repite cada cierto tiempo.
- **Pago**: incluye dinero, regalos, préstamo de producto, comisiones, descuentos y cupones. **Enviar un arnés gratis a un creador ya obliga a divulgar.**
- **Obligaciones del anunciante (Julio)**: conocer las normas del producto, pedir que se identifique la publicidad, no pedir que se oculte, tener una política de transparencia, participar en el mensaje y hacerle seguimiento, revisar comentarios por si alguien se siente engañado y difundir la guía entre los creadores.
- **Responsabilidad**: el anunciante responde por los perjuicios de la publicidad engañosa (Ley 1480, art. 30). La SIC puede ordenar retirar la publicidad (art. 59) y multar hasta 2.000 SMMLV (art. 61).

## 4. Mínimo legal del negocio que vende por redes (Colombia)

- Precio total en COP, incluido el envío si se cobra aparte, antes de cerrar el pedido.
- Derecho de retracto y garantía legal en ventas a distancia (Ley 1480): explica cómo funcionan en WhatsApp. *Verificar* el procedimiento con Dropi y el proveedor.
- Datos personales (Ley 1581 de 2012): pide autorización para guardar los datos del cliente y no publiques chats sin tapar.

## Fuentes (consultadas el 2026-11-21)

- https://support.tiktok.com/en/business-and-creator/creator-and-business-accounts/promoting-a-brand-product-or-service
- https://ads.tiktok.com/resources/help/article/how-to-turn-on-the-commercial-content-disclosure-setting-in-tiktok
- https://ads.tiktok.com/resources/help/article/about-the-commercial-content-disclosure-setting-for-advertisers
- https://support.tiktok.com/en/using-tiktok/creating-videos/ai-generated-content
- https://www.tiktok.com/tns-inapp/pages/ai-generated-content
- https://newsroom.tiktok.com/en-US/new-labels-for-disclosing-ai-generated-content
- https://ads.tiktok.com/resources/help/article/about-ad-disclaimers-in-tiktok-ads-manager
- https://ads.tiktok.com/resources/help/article/add-disclaimers-to-ads
- https://sedeelectronica.sic.gov.co/transparencia/normativa/guia-de-buenas-practicas-en-la-publicidad-traves-de-influenciadores
- https://sedeelectronica.sic.gov.co/noticias/superindustria-expide-guia-de-buenas-practicas-en-la-publicidad-traves-de-influenciadores
- https://www.elobservatodo.cl/noticia/economia/vendes-por-tiktok-las-nuevas-normas-que-deben-cumplir-los-emprendedores-para-evitar (20-nov-2026)
