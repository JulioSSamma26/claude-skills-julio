# Contenido orgánico para accesorios de mascotas

Aplica a Mascotas Seguras: arneses, collares, correas, placas de identificación, comederos, camas y juguetes. Venta por WhatsApp con contraentrega.

## Estructura de un video de 15-30 s

1. **Gancho (0-2 s)**: el problema o algo raro en pantalla, con texto grande.
2. **Producto (≤3 s)**: el accesorio puesto en la mascota.
3. **Demostración (3-20 s)**: una sola prueba concreta (tirón, lavado, medida, ajuste).
4. **Prueba social (opcional)**: captura de un cliente o un video de entrega.
5. **CTA (últimos 3 s)**: "Pídelo por WhatsApp, pagas cuando te llegue" + código.

## Ganchos probados para el nicho (adaptar, no copiar tal cual)

- "Si tu perro hace esto en el paseo, mira esto." (jala la correa)
- "Lo que nadie te dice de los collares baratos."
- "3 cosas que debes revisar antes de comprar un arnés."
- "Mi gato se escapó una vez. Nunca más sin esto." (placa)
- "¿Talla S o M? Así mides a tu perro en 10 segundos."
- "Lo probamos: ¿aguanta un tirón de 20 kg?" (solo si de verdad se probó)
- "POV: llegó el pedido y lo pagaste en la puerta."

## Prueba social que sí se puede usar

- Videos o fotos de clientes **con su permiso por escrito** (sirve un mensaje de WhatsApp que lo autorice).
- Capturas de chats: tapa nombre, número y dirección (Ley 1581 de 2012 de datos personales).
- Número de pedidos entregados en un periodo, siempre que sea verificable en Dropi.
- No inventes reseñas ni uses clientes falsos: es publicidad engañosa (Ley 1480 de 2011).

## Calendario mínimo sugerido

- 1 video diario de lunes a viernes, con 3 formatos que roten (problema → solución, prueba, cliente).
- 1 LIVE semanal de 30-45 min: tallas, dudas y cómo funciona la contraentrega. En LIVE no hay checkout porque no hay Shop, así que el CTA va a WhatsApp. Activa la divulgación de contenido comercial en el LIVE ("Divulgar contenido del LIVE" → Tu marca).
- Revisa cada viernes qué videos generaron conversaciones con código y repite el formato ganador.

## Bienestar animal en el contenido

- No pongas a la mascota en riesgo ni en estrés (tirones reales al cuello, calor, caídas).
- Las pruebas de resistencia se hacen con peso o dinamómetro, no con el animal.
- Las Normas de la Comunidad de TikTok sancionan el contenido de maltrato animal. Además, quema la confianza de la audiencia de mascotas.

## Respuestas a objeciones frecuentes (para video o para WhatsApp)

| Objeción | Respuesta corta |
|---|---|
| "¿Y si no le queda?" | Explicar la política de cambio de talla (definirla con Dropi y el proveedor antes de prometerla) |
| "¿Es seguro pagar contraentrega?" | "Pagas al recibir, en efectivo al mensajero" |
| "¿Llega a mi ciudad?" | Confirmar la cobertura en Dropi antes de responder |
| "¿Es igual al de la foto?" | Video real del producto, sin filtros que cambien color o tamaño |
