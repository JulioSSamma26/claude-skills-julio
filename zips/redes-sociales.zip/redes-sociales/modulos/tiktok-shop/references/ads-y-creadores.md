# TikTok Ads y creadores locales

> Este módulo no crea campañas, no gasta presupuesto y no inicia sesión. Solo prepara la configuración para que Julio la ejecute.

## Spark Ads

- Formato nativo que promociona un post orgánico, propio o de un creador con autorización. Las vistas, comentarios, likes y seguidores que traiga el anuncio se suman al post original (TikTok Ads, "About Spark Ads", act. jun-2026).
- Para el video de un creador, él genera un **código de autorización** y lo comparte. Fija la duración de la autorización en el acuerdo.
- Límites: video de máximo 10 min. El texto y el nombre que se muestran son los del post original y no se editan en el Administrador de anuncios. Un post sancionado también se rechaza como anuncio.
- Uso recomendado: pautar solo el video que ya ganó en orgánico (más conversaciones con código por cada 1.000 vistas).

## Anuncios de mensajes a WhatsApp (Instant Messaging Ads)

- Objetivo: **Generación de clientes potenciales** → anuncios de mensajería → destino WhatsApp.
- Requisito: un número de **WhatsApp Business API** que no esté en uso en otra cuenta de WhatsApp, personal o de empresa. Se gestiona con un proveedor de mensajería (*Messaging Partner*).
- Optimización: **Conversaciones** (recomendada; disponible para WhatsApp, Messenger y Zalo) o **Clics**.
- Fuente: https://ads.tiktok.com/resources/help/article/how-to-set-up-tiktok-instant-messaging-ads (act. oct-2025).
- *Verificar* en el Administrador de anuncios que el formato esté habilitado para anunciantes de Colombia, y el costo del proveedor de la API.
- Si no hay API: usa **Mensajes directos de TikTok** como destino (variante de mensajes directos) o un anuncio de tráfico al enlace `wa.me` (*verificar* que la política de destino lo permita).

## Prueba inicial sugerida (con el presupuesto que apruebe Julio)

1. Escoge 3-5 creativos: el ganador orgánico (Spark) más 2-4 variaciones del gancho.
2. Segmenta Colombia y las ciudades con buena tasa de entrega en Dropi.
3. Revisa a los 7 días con la métrica **costo por pedido entregado**, no con costo por clic ni por conversación.
4. Escala solo el creativo con mejor costo por entregado y apaga el resto.

## Políticas de anuncios relevantes

- **Animals and Environment**: TikTok no permite promocionar, vender ni facilitar el acceso a animales vivos o mascotas. Los accesorios están permitidos. No ofrezcas cachorros, adopciones pagas ni "regalamos un gatito con tu compra". https://ads.tiktok.com/resources/help/article/tiktok-ads-policy-animals-and-environment
- **IA**: si el anuncio trae imagen, video o audio completamente generado o muy modificado con IA, marca "Este anuncio contiene contenido generado por IA". En Spark Ads aplica la regla de las Normas de la Comunidad sobre el post orgánico. https://ads.tiktok.com/resources/help/article/add-disclaimers-to-ads

## Trabajar con creadores locales

### Modelos de pago

| Modelo | Cuándo | Riesgo |
|---|---|---|
| Producto a cambio de video | Microcreadores, primera prueba | Bajo costo, calidad variable |
| Tarifa fija por video | Creador con historial de ventas | Pagas aunque no venda |
| Comisión por pedido **entregado** con código | Relación estable | Hay que conciliar con Dropi y pagar con puntualidad |
| Mixto (producto + comisión) | El más usado en dropshipping | Requiere seguimiento por código |

Regalar el producto también es una contraprestación: obliga a divulgar (guía SIC).

### Brief mínimo para el creador

- Producto, talla enviada y 1 beneficio principal medible.
- 1-2 ganchos sugeridos; el creador lo adapta a su estilo.
- CTA: "Escríbele a Mascotas Seguras por WhatsApp con el código CREADOR01".
- **Obligatorio**: activar *Divulgar contenido comercial → Contenido de marca*, etiquetar a Mascotas Seguras como socio de marca y poner "#publicidad @mascotasseguras" en el texto y de forma visible desde el inicio.
- Prohibido: afirmar cosas que no se puedan probar, poner al animal en riesgo, generar con IA una mascota "real" sin etiqueta.
- Autorización de Spark Ads: cuántos días y para qué videos.

### Acuerdo escrito (mensaje o documento)

Debe decir: qué se entrega, plazo, pago o comisión, cómo se cuentan los pedidos entregados, la divulgación obligatoria, el permiso de uso del video y de pauta, y qué pasa si la SIC o TikTok piden un cambio. Para montos altos, que lo revise un abogado.

## Fuentes (consultadas el 2026-11-21)

- https://ads.tiktok.com/resources/help/article/spark-ads
- https://ads.tiktok.com/resources/help/article/spark-ads-creation-guide
- https://ads.tiktok.com/resources/help/article/how-to-set-up-tiktok-instant-messaging-ads
- https://ads.tiktok.com/business/en-US/blog/messaging-ads
- https://ads.tiktok.com/resources/help/article/lead-generation-objective?lang=en
- https://ads.tiktok.com/resources/help/article/tiktok-ads-policy-animals-and-environment
- https://ads.tiktok.com/resources/help/article/add-disclaimers-to-ads
