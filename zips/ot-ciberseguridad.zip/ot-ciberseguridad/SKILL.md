---
name: ot-ciberseguridad
description: "Úsala para ciberseguridad de sistemas OT/SCADA de una empresa eléctrica: zonas y conductos IEC 62443, segmentación de red OT, evaluación de seguridad de la red OT o de la red eléctrica, detección de ataques a SCADA (DNP3, IEC 60870-5-104, IEC 61850, Modbus) y plan de respuesta a incidentes OT. Úsala con \"IEC 62443\", \"segmentación OT\", \"ataque al SCADA\", \"respuesta a incidente OT\", \"evaluación de seguridad de subestaciones\". NO usar para seguridad de código (usar desarrollo-codigo o /security-review) ni para revisar skills (usar orquestador-skills)."
---

# Ciberseguridad OT / SCADA

Fusión de 6 skills de mukul975/Anthropic-Cybersecurity-Skills (Apache-2.0, ~36k estrellas). **No es un proyecto de Anthropic**, aunque el nombre del repositorio lo diga. Se copió solo el texto (SKILL.md y referencias); **sus scripts se omitieron a propósito**.

| Necesidad | Módulo | Leer |
|---|---|---|
| Definir zonas, conductos y niveles de seguridad (SL) según IEC 62443 | `implementing-iec-62443-security-zones` | `modulos/implementing-iec-62443-security-zones/GUIA.md` |
| Segmentar la red OT (modelo Purdue, DMZ, firewalls) | `implementing-network-segmentation-for-ot` | `modulos/implementing-network-segmentation-for-ot/GUIA.md` |
| Evaluar la seguridad de una red OT | `performing-ot-network-security-assessment` | `modulos/performing-ot-network-security-assessment/GUIA.md` |
| Evaluar la ciberseguridad de la red eléctrica (subestaciones, centro de control) | `performing-power-grid-cybersecurity-assessment` | `modulos/performing-power-grid-cybersecurity-assessment/GUIA.md` |
| Detectar ataques a SCADA (protocolos industriales, comportamiento anómalo) | `detecting-attacks-on-scada-systems` | `modulos/detecting-attacks-on-scada-systems/GUIA.md` |
| Plan o ejecución de respuesta a incidentes OT | `implementing-ot-incident-response-playbook` | `modulos/implementing-ot-incident-response-playbook/GUIA.md` |

Guías en inglés; responde en español. Si una guía cita `scripts/agent.py` u otro script, ese archivo no está: trabaja con el método descrito, sin ejecutar nada.

## Reglas inquebrantables

1. **Nunca escaneos activos** (nmap, escáneres de vulnerabilidades, fuzzing de protocolos, pruebas de intrusión) sobre la red OT, el SCADA en producción ni equipos de subestación. Un escaneo puede tumbar una RTU o un IED. Solo análisis pasivo (capturas que entregue el área responsable, configuraciones, documentación) y siempre con autorización escrita.
2. **Datos de Afinia:** topologías, direcciones IP, nombres de puntos, configuraciones de firewall y listas de señales no salen de la empresa ni se pegan en servicios externos. Para trabajar con Claude, anonimizar primero (p. ej. `RTU_A`, `10.x.x.x`).
3. **Spectrum Power 7:** las recomendaciones deben respetar lo que soporta el proveedor (Siemens). Si algo implica tocar la configuración del sistema de control, se marca como "validar con el fabricante y el área de seguridad".
4. **Marco regulatorio:** en Colombia, citar el marco que aplique a Afinia (políticas de Grupo EPM y regulación sectorial vigente). Si la guía cita NERC CIP (Estados Unidos), presentarlo como referencia de buenas prácticas, no como obligación.
5. **Entregables** en lenguaje de ingeniería: hallazgo → riesgo concreto → recomendación → responsable → plazo (formato de `humanizador` para informes de Afinia).
