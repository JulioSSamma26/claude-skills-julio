---
name: desarrollo-codigo
description: "Úsala al escribir, depurar o revisar código (Python, VBA, SQL, Airflow, Docker, JS): diagnosticar un bug o error, TDD con pruebas primero, verificar antes de decir que algo funciona, responder a una revisión de código, cuestionar una solución antes de aplicarla, ejecutar un plan con un subagente por tarea, o revisar un PR por pasadas (errores silenciados, pruebas, tipos, comentarios). Úsala con \"no funciona\", \"falla\", \"depura\", \"haz TDD\", \"revisa este PR\", \"ya quedó?\". NO usar para planificar un proyecto difuso (usar superpowers) ni para SQL del historiador SCADA (usar oracle-scada-historian)."
---

# Desarrollo de código con disciplina

Fusión de 8 skills de alto rating: obra/superpowers (MIT), mattpocock/skills (MIT), addyosmani/agent-skills (MIT) y pr-review-toolkit de Anthropic (Apache-2.0). Lee solo el módulo que necesitas.

| Situación | Módulo | Leer |
|---|---|---|
| Bug o error: primero un ciclo rápido de reproducción pasa/falla, luego hipótesis | `diagnosing-bugs` | `modulos/diagnosing-bugs/GUIA.md` |
| Bug difícil o que volvió: causa raíz, defensa en profundidad, esperas por condición | `systematic-debugging` | `modulos/systematic-debugging/GUIA.md` |
| Escribir código nuevo con pruebas primero, una prueba vertical a la vez | `tdd` | `modulos/tdd/GUIA.md` |
| Antes de decir "listo", "funciona" o "pasó" | `verification-before-completion` | `modulos/verification-before-completion/GUIA.md` |
| Llegó una revisión de código con comentarios | `receiving-code-review` | `modulos/receiving-code-review/GUIA.md` |
| Decisión técnica dudosa: cuestionarla antes de aplicarla | `doubt-driven-development` | `modulos/doubt-driven-development/GUIA.md` |
| Plan con varias tareas: un subagente fresco por tarea, revisión en dos etapas, bitácora en disco | `subagent-driven-development` | `modulos/subagent-driven-development/GUIA.md` |
| Revisar un PR o diff por pasadas especializadas | `pr-review-toolkit` | `modulos/pr-review-toolkit/GUIA.md` |

Rutas internas de cada guía: relativas a su carpeta. Guías en inglés; responde en español.

## Reglas que aplican siempre (no requieren cargar módulos)

1. **Ley de hierro de la verificación:** no afirmar que algo funciona, pasa o está arreglado sin haber ejecutado en este turno el comando que lo prueba y leído su salida. Si no se pudo ejecutar, decirlo.
2. **Bug → reproducir antes de teorizar:** construir el ciclo más rápido posible que muestre pasa/falla; después 3 a 5 hipótesis ordenadas; logs de depuración con un prefijo único (p. ej. `[DBG-7f3]`) para borrarlos todos al final.
3. **Tras 3 intentos fallidos de arreglo**, parar y cuestionar la arquitectura en lugar de un cuarto parche.
4. **Revisión recibida:** verificar cada comentario contra el código antes de aplicarlo; no aceptar por cortesía ni rechazar por orgullo.

## Afinia

- Oracle solo lectura y con ventana acotada (`oracle-scada-historian`); credenciales en variables de entorno; nada de datos de Afinia en pruebas que salgan de la red.
- Scripts del módulo `subagent-driven-development` (`scripts/`) son bash que solo generan archivos locales con git; en Windows ejecutarlos desde Git Bash.

## Relación con otras skills

- `superpowers` define y planifica; esta skill ejecuta con disciplina. `subagent-pool` orquesta proyectos de 3+ archivos y puede usar el módulo `subagent-driven-development` como método.
- Si una guía cita `superpowers:<x>`: `test-driven-development` → módulo `tdd`; `verification-before-completion`, `systematic-debugging`, `receiving-code-review` → su módulo aquí; `brainstorming` / `writing-plans` → skill `superpowers`; `using-git-worktrees` / `finishing-a-development-branch` → no instaladas, seguir sin ellas.
