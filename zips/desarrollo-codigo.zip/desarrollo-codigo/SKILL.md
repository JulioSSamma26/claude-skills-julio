---
name: desarrollo-codigo
description: "Úsala al escribir, depurar o revisar código (Python, VBA, SQL, Airflow, Docker, JS): diagnosticar un bug o error, TDD con pruebas primero, verificar antes de decir que algo funciona, responder a una revisión de código, cuestionar una solución antes de aplicarla, ejecutar un plan con un subagente por tarea, o revisar un PR por pasadas (errores silenciados, pruebas, tipos, comentarios). Úsala con \"no funciona\", \"falla\", \"depura\", \"haz TDD\", \"revisa este PR\", \"ya quedó?\". NO usar para planificar un proyecto difuso (usar superpowers) ni para SQL del historiador SCADA (usar oracle-scada-historian)."
---

# Desarrollo de código con disciplina

Fusión de 8 skills de alto rating: obra/superpowers (MIT), mattpocock/skills (MIT), addyosmani/agent-skills (MIT) y pr-review-toolkit de Anthropic (Apache-2.0). Lee solo el módulo que necesitas.

| Situación | Módulo | Leer |
|---|---|---|
| Bug o error: primero un ciclo rápido de reproducción pasa/falla, luego hipótesis | `diagnosing-bugs` | `modulos/diagnosing-bugs/GUIA.md` |
| Bug difícil o que volvió: causa raíz, defensa en profundidad, esperas por condición | `systematic-debugging` | `modulos/systematic-debugging/GUIA.md` |
| Escribir código nuevo con pruebas primero, una prueba vertical a la vez | `tdd` | `modulos/tdd/GUIA.md` |
| Antes de decir "listo", "funciona" o "pasó" | `verification-before-completion` | `modulos/verification-before-completion/GUIA.md` |
| Llegó una revisión de código con comentarios | `receiving-code-review` | `modulos/receiving-code-review/GUIA.md` |
| Decisión técnica dudosa: cuestionarla antes de aplicarla | `doubt-driven-development` | `modulos/doubt-driven-development/GUIA.md` |
| Plan con varias tareas: un subagente fresco por tarea, revisión en dos etapas, bitácora en disco | `subagent-driven-development` | `modulos/subagent-driven-development/GUIA.md` |
| Revisar un PR o diff por pasadas especializadas | `pr-review-toolkit` | `modulos/pr-review-toolkit/GUIA.md` |

Rutas internas de cada guía: relativas a su carpeta. Guías en inglés; responde en español.

## Reglas que aplican siempre (no requieren cargar módulos)

1. **Ley de hierro de la verificación:** no afirmar que algo funciona, pasa o está arreglado sin haber ejecutado en este turno el comando que lo prueba y leído su salida. Si no se pudo ejecutar, decirlo.
2. **Bug → reproducir antes de teorizar:** construir el ciclo más rápido posible que muestre pasa/falla; después 3 a 5 hipótesis ordenadas; logs de depuración con un prefijo único (p. ej. `[DBG-7f3]`) para borrarlos todos al final.
3. **Tras 3 intentos fallidos de arreglo**, parar y cuestionar la arquitectura en lugar de un cuarto parche.
4. **Revisión recibida:** verificar cada comentario contra el código antes de aplicarlo; no aceptar por cortesía ni rechazar por orgullo.

## Antes de editar un archivo por primera vez (portón de hechos)

No basta con "creo que está bien": antes del primer cambio a un archivo, deja escritos estos hechos.
- **Quién lo usa:** qué archivos o DAGs lo importan o lo llaman (búscalo; no lo supongas).
- **Qué cambia hacia fuera:** funciones, columnas, nombres de archivo o formatos de salida que otros consumen.
- **El esquema real de los datos** que lee o escribe: columnas, tipos y formato de fechas, comprobados con 3 a 5 filas reales y con los valores sensibles enmascarados. Nunca asumas ISO ni nombres de columna; en BD_SCADA y `his_message` el formato real manda.
- **La instrucción del usuario, citada**, que justifica el cambio.

En comandos que borran o sobrescriben algo, escribe primero qué se modifica y **una línea de cómo volver atrás** (respaldo, `git`, copia). En rutas sensibles no hay atajos: archivos de variables de entorno, credenciales y llaves privadas, carpetas de secretos, migraciones, flujos de CI, DAGs de producción y conexiones de Airflow.

## Verificación en el entorno destino

"Pasa en mi PC" no es "funciona". Cierra cada entrega con una línea:
`Destino: VERIFICADO | FALLÓ | NO REALIZADO (sin acceso) | NO APLICA` y el siguiente paso permitido.
Destinos típicos: el Airflow en WSL, el flujo de Power Automate, una consulta contra SGDPROD o 12c y el informe generado. Nunca se prueba en producción sin autorización.

## Revisión rápida de Python (bloquean la entrega)

SQL armado con f-strings (en Oracle usar variables bind) · `except: pass` o excepciones tragadas · argumentos por defecto mutables · `subprocess` con `shell=True` o con una cadena en vez de una lista · `print()` donde debería ir `logging` en DAGs y scripts programados · `yaml.load` sin `SafeLoader`.

<!-- Ideas adaptadas y reescritas de affaan-m/ECC v2.2.3 (MIT, Copyright (c) 2026 Affaan Mustafa), commit 4adeee6, revisado el 2026-11-21: gateguard, verification-loop, python-reviewer -->

## Afinia

- Oracle solo lectura y con ventana acotada (`oracle-scada-historian`); credenciales en variables de entorno; nada de datos de Afinia en pruebas que salgan de la red.
- Scripts del módulo `subagent-driven-development` (`scripts/`) son bash que solo generan archivos locales con git; en Windows ejecutarlos desde Git Bash.

## Relación con otras skills

- `superpowers` define y planifica; esta skill ejecuta con disciplina. `subagent-pool` orquesta proyectos de 3+ archivos y puede usar el módulo `subagent-driven-development` como método.
- Si una guía cita `superpowers:<x>`: `test-driven-development` → módulo `tdd`; `verification-before-completion`, `systematic-debugging`, `receiving-code-review` → su módulo aquí; `brainstorming` / `writing-plans` → skill `superpowers`; `using-git-worktrees` / `finishing-a-development-branch` → no instaladas, seguir sin ellas.
