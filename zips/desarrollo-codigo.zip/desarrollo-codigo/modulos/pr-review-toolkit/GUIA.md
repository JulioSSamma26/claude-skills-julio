# Revisión de PR por pasadas especializadas

Seis prompts de revisor de Anthropic (pr-review-toolkit). Cada archivo es el prompt de un subagente: léelo y úsalo como instrucción para un subagente (o aplícalo tú mismo) sobre el diff.

| Archivo | Pasada |
|---|---|
| `silent-failure-hunter.md` | Errores tragados, catch vacíos, fallbacks que ocultan fallas |
| `pr-test-analyzer.md` | Huecos de cobertura y calidad de las pruebas |
| `type-design-analyzer.md` | Diseño de tipos e invariantes |
| `comment-analyzer.md` | Comentarios falsos, obsoletos o que sobran |
| `code-reviewer.md` | Revisión general contra las convenciones del proyecto |
| `code-simplifier.md` | Simplificar sin cambiar comportamiento |

Elige solo las pasadas que aplican al cambio; no las seis siempre.
