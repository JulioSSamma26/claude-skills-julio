---
name: humanizador
description: "Reescribe textos que suenan a IA o a plantilla corporativa para que suenen naturales, directos y creíbles, conservando exactos los datos técnicos; también limpia huellas de IA (rayas, palabras comodín, caracteres invisibles). Úsala con \"humaniza\", \"que no suene a IA\", \"hazlo más natural/directo\", \"revisa este correo\" o como paso final de linkedin, email-marketing, redes-sociales, contenido e internal-comms. NO usar para verificar si los datos son ciertos (usar verificador-datos) ni para mejorar copy de venta (usar copywriting)."
---

# Humanizador

Única skill para quitar el tono de IA. Sustituye a content-humanizer y cubre lo mismo que `ig-human` del plugin instagram-agent (si las dos están disponibles, usar esta, salvo que el usuario pida el puntaje de detección de `ig-human`).

## Qué detecta y corrige

**1. Frases comodín de IA**
- "Espero que estés bien", "Espero que este mensaje te encuentre bien"
- "En el mundo actual", "En el panorama actual", "En la era digital"
- "Es importante destacar", "Cabe mencionar", "Sin duda", "Vale la pena resaltar"
- "Aprovecha el poder de", "Desbloquea el potencial", "Lleva tu negocio al siguiente nivel"
- "En este sentido", "Por otro lado", "Además, cabe destacar que" usados como relleno
- "En conclusión", "En resumen" para abrir el cierre
- "Quedo atento a cualquier inquietud" como cierre automático
- En inglés: "delve", "leverage", "seamless", "robust", "game-changer", "in today's fast-paced world", "it's worth noting"

**2. Estructura artificial**
- Tríadas constantes ("rápido, eficiente y seguro")
- "No solo X, sino también Y" repetido
- Rayas (—) para incisos: reemplazar por coma, punto o paréntesis
- Preguntas retóricas para abrir párrafos
- Párrafos con la misma forma uno tras otro; todas las frases del mismo largo
- Cierres motivacionales o demasiado pulidos
- Emojis como viñetas en textos profesionales

**3. Tono inflado:** entusiasmo o promesas exageradas; palabras grandes donde basta una sencilla ("robusto", "integral", "disruptivo", "potenciar", "sinergia"); marketing vacío.

**4. Vaguedad:** beneficios genéricos sin detalle, frases bonitas sin contenido, relleno.

**5. Falta de voz:** tono impersonal de plantilla, ningún matiz de quien escribe.

**6. Huellas técnicas (limpiar siempre, en silencio):** caracteres invisibles (espacio de ancho cero U+200B, U+200C, U+200D, U+FEFF, espacio duro U+00A0 fuera de cifras+unidad), comillas o guiones raros pegados desde otra IA, y negritas/markdown en textos que van a un correo o mensaje real.

## Cómo reescribe

- Mantener significado, intención e idioma. En español, respetar el trato (tú / usted).
- Decir lo mismo con menos palabras; frases naturales aunque no sean perfectas; variar el largo de las frases.
- Sustituir palabras infladas por expresiones concretas. Eliminar relleno.
- No alargar salvo que sea necesario. No añadir información inventada.

## Datos que nunca se tocan

Cifras, porcentajes, fechas, horas, nombres de señales y equipos (P1_48, BCU_01, códigos de circuito, subestaciones), sistemas (Spectrum Power 7, Survalent, Oracle, Power Automate), personas, condiciones, plazos y promesas. Se copian exactos. Si un dato parece incorrecto, no se corrige en silencio: se señala en "Cambios principales" (y, si importa, se sugiere `verificador-datos`).

## Según el tipo de texto

**Correos e informes de trabajo (Afinia)**
- Sin aperturas de plantilla ni cierres motivacionales: al punto en la primera línea.
- Listas largas de viñetas explicativas → prosa corta.
- Excepción: responsables, acciones y fechas en un bloque corto y separado ("Acción – Responsable – Fecha"), nunca mezclados en el párrafo.
- Riesgos con nombre propio ("si no se corrige antes del viernes, el informe mensual sale con el dato de octubre"), no eufemismos ("podría haber impactos").
- Profesional y directo, no coloquial.

**Redes y marketing (LinkedIn, Instagram, blog, anuncios)**
- Que suene a la persona que publica, no a una marca genérica. Frases cortas, ritmo variado, una idea por párrafo.
- Conservar ganchos, CTAs y límites de caracteres de la skill de origen.

## Proceso

1. Leer el texto completo; identificar tipo y destinatario.
2. Marcar patrones artificiales y datos intocables.
3. Reescribir.
4. Releer en voz baja: si una frase no la diría una persona, cambiarla.
5. Comprobar que todos los datos del original siguen presentes y exactos, y que no quedan rayas ni caracteres invisibles.

## Formato de respuesta

**Texto humanizado:**
[versión final lista para copiar; sin negritas ni formato si es un correo o mensaje real]

**Cambios principales:** (2 a 4 líneas) qué se quitó o cambió y cualquier dato dudoso.

**Modo apoyo** (llamada desde linkedin, email-marketing, redes-sociales, contenido, internal-comms u otra skill): entregar solo el texto humanizado dentro del formato de esa skill, sin bloque de cambios.

## Reglas

- No justificar cada decisión ni dar varias versiones salvo que se pidan.
- No volver coloquial un texto que requiere profesionalidad.
- No eliminar información importante.
- No añadir emojis salvo que el original los use o se pidan.
- El objetivo es que suene a persona real, no que suene peor.
