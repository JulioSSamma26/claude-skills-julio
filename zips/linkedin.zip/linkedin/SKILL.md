---
name: linkedin
description: "Todo LinkedIn de Julio y Maillyn en una skill: escribir posts con 21 fórmulas de gancho, notas de conexión de 200 caracteres con DM y seguimientos, responder comentarios de posts propios priorizando posibles clientes, y mejorar perfil (titular, Acerca de, experiencia). Úsala con \"post de LinkedIn\", \"gancho\", \"nota de conexión\", \"DM\", \"seguimiento\", \"responde estos comentarios\", \"mejora mi perfil de LinkedIn\". NO usar para otras redes (usar redes-sociales o instagram-agent) ni para correos en frío (usar email-marketing)."
---

# LinkedIn

Fusión de li-post, li-dm y li-reply, más un modo de perfil. Adaptada en parte de aldushmedia/linkedin-agent-skill-es (licencia MIT, Copyright (c) 2026 Jake Schincariol).

## Paso 0: elegir el modo

| La petición | Modo |
|---|---|
| Idea, borrador o tema para publicar | **A. Post** |
| Contactar a alguien concreto | **B. Conexión y DM** |
| Pega comentarios de un post propio | **C. Responder comentarios** |
| Titular, "Acerca de", experiencia, foto/banner | **D. Perfil** |

Anuncia el modo en una línea y sigue solo esa sección.

## Reglas para todos los modos

- **Voz de quien publica.** Si la conoces por la conversación o por posts suyos, úsala. Si no, pide tres posts anteriores y dedúcela. Nunca inventes una voz: un texto con la voz equivocada es peor que no publicar. Julio y Maillyn tienen voces distintas; pregunta para quién es si no está claro.
- **Nunca inventes** métricas, clientes, ingresos, conexiones en común ni haber leído algo. Si falta un dato, deja `{{tu número}}` y márcalo.
- **Nunca publiques ni envíes.** Esta skill produce texto; el usuario lo pega a mano. Nada de automatizar conexiones ni mensajes (viola el Acuerdo de Usuario de LinkedIn y restringe la cuenta).
- **Humaniza** cada texto final con `humanizador` (modo apoyo: solo el texto, sin bloque de cambios).
- **Datos de Afinia:** un post sobre el trabajo puede contar el aprendizaje, pero nunca nombres de puntos, señales, rutas internas, cifras no públicas ni credenciales.

---

## A. Post

### Antes de escribir
1. Si la idea es pobre ("un post sobre IA"), no la rellenes: haz **una** pregunta que lo junte todo: qué pasó, a quién y qué costó o qué dejó. Un post necesita una cosa específica y verdadera.
2. Elige fórmulas de gancho en `references/ganchos.md` (21 fórmulas con plantilla, uso y trampa).

### Reglas del gancho
- Una idea por gancho. La línea 2 es la recompensa de la línea 1, nunca la preparación.
- Sin signo de pregunta en la línea 1, salvo pregunta muy específica.
- Números antes que adjetivos.
- Si el gancho funciona con el nombre de otra persona, no es su gancho.
- El feed corta en ~210 caracteres en escritorio y ~140 en el teléfono.

### Forma
```
Línea 1    gancho, solo; sobrevive al corte de ~140 caracteres
Línea 2    recompensa de la línea 1
Cuerpo     párrafos de 1 a 3 líneas con línea en blanco entre ellos
Giro       una línea que replantea lo anterior
Cierre     una pregunta específica o una instrucción, nunca las dos
```
Extensión 900 a 1300 caracteres (menos de 400 se lee como un pensamiento suelto). Máximo tres hashtags al final. Enlaces en el primer comentario, no en el cuerpo. Nada de cebo tipo "¿Qué opinan?".

### Ciclo
1. Tres ganchos de fórmulas distintas, numerados, y cuál publicarías y por qué (una oración).
2. Post completo con el más fuerte.
3. Humanizar.
4. Bloque listo para copiar y, debajo: gancho usado, caracteres y "Responde sí o dime qué cambiar".

Si el usuario quiere verificar cifras o afirmaciones antes de publicar, pásalo por `verificador-datos`.

---

## B. Conexión y DM

La nota de invitación tiene 200 caracteres; el primer DM decide si habrá un segundo. Ninguno es una venta.

### Datos necesarios (una sola pregunta que lo junte todo)
1. **Quién:** nombre, cargo, empresa.
2. **Motivo real para escribir hoy:** un post suyo, un lanzamiento de su empresa, una conexión en común, una charla. No "encaja con mi cliente ideal". Si no hay motivo específico, dilo.
3. **Qué quiere el usuario:** conversación, recomendación, trabajo, venta (honesto internamente aunque el mensaje no empiece por ahí).

### Nota de invitación
`{referencia específica a la persona} + {una línea de quién eres} + {sin pedir nada}`. Menos de 200 caracteres con espacios: cuéntalos y muestra el conteo `[170/200]`.

### Primer DM (un día después de que acepte)
- 2 a 4 oraciones; menciona lo específico de la nota.
- Da algo antes de pedir (un número, una plantilla, un nombre, una respuesta).
- Un pedido pequeño ("¿te sirve una llamada de 15 minutos?"). Sin enlace de calendario.

### Seguimientos: dos y se para
- **Día 4:** algo nuevo. Nunca "solo para recordarte". Sin nada nuevo, no hay seguimiento.
- **Día 10:** cierre: di que dejas de escribir y cúmplelo.
- Nunca más de 20 invitaciones por día. Nunca "Espero que este mensaje te encuentre bien".

**Entrega:** nota con conteo, primer DM y los dos seguimientos con su día.

---

## C. Responder comentarios

Entrada: comentarios pegados (o capturas), idealmente con nombre y cargo. No extraigas el hilo con un navegador.

### Clasificar primero y dar conteos
| Grupo | Qué es | Qué recibe |
|---|---|---|
| POSIBLE CLIENTE | describe el problema que el usuario resuelve | respuesta real + puerta abierta suave |
| APORTE | suma datos, discrepa, amplía | la respuesta más larga del hilo |
| COLEGA | nombre con el que vale la pena que lo vean | una respuesta que le dé algo |
| APOYO | "gran post", 🔥, etiqueta | me gusta y como mucho 3 a 8 palabras |
| RUIDO | venta, spam, mala fe | nada o una línea |

### Cómo responder
- Responde la pregunta de verdad; si preguntan cómo, di cómo.
- Su nombre una vez, al inicio, sin exclamación. Iguala su extensión.
- Crítico: reconoce la parte cierta con sus palabras y sostén tu punto. Nunca borrar, nunca a la defensiva, nunca dos respuestas en el mismo hilo.
- Posible cliente: respuesta completa en público; la puerta abierta es una oración final de ayuda, no una venta.
- Venta en tus comentarios: ignorar.

**Entrega:**
```
RESPUESTAS · 17 comentarios · 1 POSIBLE CLIENTE, 3 APORTE, 4 COLEGA, 8 APOYO, 1 RUIDO

POSIBLE CLIENTE
@Nombre: "comentario"
> respuesta
```

---

## D. Perfil

1. Pide (o lee) el perfil actual: titular, Acerca de, experiencia reciente, a quién quiere atraer (reclutadores de automatización/SCADA, clientes freelance, marca personal).
2. **Titular (≤220 caracteres):** qué resuelve + para quién + prueba concreta. Nada de "apasionado por".
3. **Acerca de:** primera línea con gancho (se corta a ~300 caracteres), 3 a 5 párrafos cortos, logros con números reales, cierre con qué tipo de contacto busca.
4. **Experiencia:** cada rol con 2 a 4 logros medibles (verbo + resultado + número), no funciones.
5. Entrega: versión nueva de cada sección lista para pegar y una lista de 3 cambios de mayor impacto. Para apoyo de estructura persuasiva, se puede consultar `copywriting`.
