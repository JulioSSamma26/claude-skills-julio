# Las 21 fórmulas de gancho

Adaptadas de aldushmedia/linkedin-agent-skill-es (MIT). Elige tres de fórmulas distintas por post.

| # | Nombre | Plantilla | Sirve para | Trampa |
| --- | --- | --- | --- | --- |
| 1 | A contracorriente | Todos dicen {consejo común}. Después de {experiencia}, creo que está mal. | Marcar punto de vista; la que más comentarios saca | Ir contra algo que nadie cree |
| 2 | El número revelado | Hice {algo} durante {N} {días}. Esto es lo que pasó de verdad. | Experimentos con resultado contable | Esconder el número |
| 3 | Confesión de un error | {Costo específico} es lo que me costó {un error}. | Confianza | Falsa humildad |
| 4 | Antes / después | Hace {tiempo} yo {estado bajo}. Hoy {estado alto}. La diferencia fue {una cosa}. | Probar que recorriste el camino | Transformaciones en tres partes |
| 5 | La lista prometida | {N} cosas que me habría gustado saber antes de {hito}. | Guardados | N mayor que 10 |
| 6 | Secreto del oficio | Después de {N} años {haciendo algo}, esta es la parte que nadie cuenta. | Opiniones con credenciales | Prometer secreto y dar algo obvio |
| 7 | El llamado de atención | Si todavía {haces algo que ya no sirve}, para. | Posts cortos de una instrucción | Desprecio a tu audiencia |
| 8 | La pregunta trampa | {Escenario con costo real}. ¿Qué haces? | Comentarios | Pregunta con respuesta obvia |
| 9 | Arranque en frío | "{Línea de diálogo}" + quién lo dijo y por qué importó. | Historias largas | Diálogo que nadie diría |
| 10 | La prueba | {Número duro}. {Una oración de contexto}. | Lo que puedas probar | Prueba sin historia |
| 11 | Derribar el mito | {Explicación popular} no es la razón de {mal resultado}. | Replantear | No nombrar la causa real |
| 12 | La comparación | {Opción cara} vs {opción barata}. {Veredicto sorprendente}. | Herramientas y procesos | Comparación injusta |
| 13 | El permiso | Tienes permiso para {algo que da culpa}. | Alcance fuera del nicho | Autocuidado genérico |
| 14 | Corte de patrón | {Una palabra o línea corta, con punto}. | Frenar el desplazamiento | Abusar de ella |
| 15 | La advertencia | {Práctica común} te está costando {algo específico}. | Conectar causa con costo | Miedo sin solución |
| 16 | Bueno vs excelente | Los buenos {rol} {hacen X}. Los excelentes {hacen Y}. | Frases citables | Que sea solo "esfuérzate más" |
| 17 | Ancla de tiempo | {Tarea} me llevaba {mucho}. Ahora me lleva {poco}. | Automatización y sistemas | Proporción increíble |
| 18 | La regla impopular | No {práctica aceptada}. Nunca. Esta es la razón. | Posicionamiento | Regla que rompes |
| 19 | Brecha de curiosidad | {Lo mejor/peor} que {verbo} {rompió la regla obvia}. | Forzar "ver más" | Nunca cerrar la brecha |
| 20 | Lo que dejé ir | {Dejé} {algo valioso}. {Resultado}. | Valores con resultado | Dejar ir algo sin costo |
| 21 | Valor directo | Este es el {recurso} exacto que usé para {resultado}. Llévatelo. | Imanes de clientes | Pedir algo que podías regalar |
