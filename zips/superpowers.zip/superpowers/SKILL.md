---
name: superpowers
description: "Método de trabajo de principio a fin para construir algo con varias partes (app, automatización, script, flujo, sistema, skill nueva, documento complejo): si la idea está difusa, primero entrevista al usuario hasta tener requisitos claros; después planifica, prevé riesgos, construye y verifica. Úsala con \"quiero automatizar X\", \"ayúdame a definir Y\", \"constrúyeme\", \"hazlo bien\", \"crea una skill para\". NO usar para preguntas rápidas o cambios de una línea, ni para orquestar subagentes en un repositorio de código de 3+ archivos (usar subagent-pool)."
---

# Superpowers: definir → construir → verificar

Fusión de superpowers y entrevistador-procesos. Una sola skill recorre todo el camino, así nunca compiten.

## Principio

No ejecutar sin pensar, y no pensar más de lo necesario. Como un profesional senior: entender, planificar y validar; después construir y comprobar. La profundidad se ajusta al tamaño de la tarea.

## Paso 0: elegir la fase de entrada

| Situación | Empieza en |
|---|---|
| Requisitos difusos: "quiero automatizar X" sin saber cómo, skill nueva sin definir | **Fase 1: Entrevista** |
| Requisitos claros, tarea mediana (un script, un flujo, una función, un documento de pocas partes) | **Fase 2: Modo exprés** |
| Requisitos claros, tarea grande (piezas que dependen entre sí, va a producción, el usuario pide plan) | **Fase 2: Modo completo** |
| Proyecto de código con 3+ archivos o módulo nuevo en un repo | Pasar a `subagent-pool` (puede usar el resumen de la Fase 1 como entrada) |

Anuncia en una línea la fase elegida.

---

## Fase 1: Entrevista (solo si hace falta)

Objetivo: sacar de la cabeza del usuario lo necesario para construir, en el menor número de preguntas.

**Antes de preguntar**
1. Revisa lo que ya se sabe (conversación, adjuntos, memoria). No preguntes lo ya respondido: confírmalo en una línea ("Entiendo que el flujo usa solo conectores estándar, ¿correcto?").
2. Elige solo los bloques necesarios. Meta: 5 a 10 preguntas en total; más de 12 es preguntar de más.

**Cómo preguntar**
- Abiertas: una por turno. Cerradas (formato, frecuencia, herramienta, sí/no): hasta 3 o 4 juntas, como opción múltiple si la interfaz lo permite.
- Tras cada respuesta: "Lo que entiendo hasta ahora: [resumen]. Siguiente pregunta: [pregunta]".
- Respuesta vaga → pide un ejemplo concreto. Usuario muy seguro → busca igual excepciones.
- "Asume lo demás" o "ya, construye" → cierra la entrevista con supuestos marcados.

**Bloques (solo los necesarios):** contexto (qué, para quién, qué problema) · proceso actual (pasos manuales, errores, herramientas) · resultado deseado (formato, detalle, qué lo hace bueno) · reglas y excepciones (límites, qué preguntar antes de actuar) · ejemplos reales de entrada y salida (en Afinia, ficticios o anonimizados) · cierre ("¿algo importante que no haya preguntado?").

**En procesos de Afinia comprueba siempre:** dónde viven los datos y si pueden salir, licencias (conectores estándar), quién aprueba los cambios y dónde se documentan.

**Resumen final de la entrevista:** objetivo · usuario o destinatario · flujo paso a paso · entradas · salidas · reglas · excepciones · criterios de calidad · supuestos y pendientes · siguiente acción.

**Si el objetivo es una skill, añade un brief:** nombre kebab-case · descripción (qué hace, cuándo activarse, "NO usar para X (usar Y)", ≤1024 caracteres) · frases que la activan · flujo · formato de salida · 2 ejemplos reales · errores a evitar · con qué skill del mapa de `orquestador-skills` podría pisarse. Con el brief aprobado, construir con `skill-creator`.

La entrevista termina cuando el proceso se puede describir paso a paso sin ambigüedades y otra persona podría construirlo con el resumen. Entonces pasa a la Fase 2 sin pedir permiso de nuevo, salvo que el usuario quiera revisar el resumen.

---

## Fase 2: Construir

### Modo exprés
1. **Plan en 3 a 6 líneas:** qué, en qué orden, supuestos `[Supuesto: ...]` y el riesgo principal.
2. **Construir.**
3. **Comprobar:** ejecutar o probar lo construido cuando sea posible y decir qué se probó y qué no.

Sin los encabezados del modo completo.

### Modo completo
1. **Objetivo:** resultado esperado, quién lo usa, restricciones. Si falta algo crítico, máximo 3 preguntas juntas; si es menor, `[Supuesto: ...]`.
2. **Plan:** componentes, orden y dependencias, decisiones, riesgos y casos límite. Lo justo para detectar problemas.
3. **Criterios de calidad:** qué debe funcionar sí o sí, qué casos probar, qué lo dejaría incompleto.
4. **Ejecutar:** seguir el plan sin añadir funciones no pedidas; lo más simple posible; señalar decisiones importantes. Código → cómo probarlo. Automatizaciones → fallos posibles y su manejo. Documentos → cómo evaluarlos.
5. **Verificar:** contra la especificación (¿falta o sobra algo?, ¿casos límite?) y calidad (claro, robusto, mantenible). Probar de verdad; no declarar "funciona" sin ejecutarlo.

Formato:
```
## 1. Objetivo
## 2. Supuestos y preguntas
## 3. Plan
## 4. Riesgos y casos límite
## 5. Criterios de calidad
## 6. Resultado
## 7. Verificación
```
Las secciones 1 a 5 juntas no ocupan más que el resultado.

**Antes de construir una utilidad, busca primero:** en el repo, en tus skills, en PyPI o npm y en GitHub. Decide entre adoptar tal cual, extender con una capa fina, combinar 2 o 3 paquetes pequeños, o construir; la licencia (MIT o Apache) y el mantenimiento cuentan en la decisión.

**La verificación termina con una línea de destino:** `Destino: VERIFICADO | FALLÓ | NO REALIZADO (sin acceso) | NO APLICA`. Que pase en local no prueba que funcione en el Airflow de WSL, en Power Automate ni contra SGDPROD.

---

## Comprobaciones fijas para trabajo de Afinia

Si lo construido toca SCADA, Oracle, Power Automate, Airflow o Docker en Afinia, incluir en riesgos y verificación:

- Datos de Afinia (BDI, BD_SCADA, señales, nombres de puntos, credenciales) no salen a servicios externos.
- Oracle solo lectura y ventana acotada (`oracle-scada-historian`).
- Power Automate solo con conectores estándar (`power-automate-afinia`).
- Credenciales en variables de entorno, nunca en el código.
- Cómo volver a la versión anterior si algo falla.
- Si hay control de cambios, el texto para documentarlo.

## Reglas

- No dar una solución rápida a una tarea compleja ni planificar de más una simple.
- No preguntar lo que se puede asumir razonablemente; no construir antes de entender lo crítico.
- Lenguaje técnico solo el que el usuario necesita.
- Prioridad: claridad, fiabilidad y utilidad práctica.
