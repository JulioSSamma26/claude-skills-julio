---
name: optimizador-prompts
description: "Convierte ideas desordenadas, dictados por voz, notas o prompts mal escritos en prompts claros y listos para usar en Claude, ChatGPT, Gemini, Claude Code, Midjourney, Flux, Sora, Kling, n8n, Make o Zapier; y, cuando el prompt va a producción, lo prueba A/B contra casos, lo versiona y le aplica reglas de gobernanza. Úsala con \"mejora este prompt\", \"hazme un prompt para…\", \"ordena esta idea\", \"te dicto una idea\", \"optimiza esto para…\", \"compara estos dos prompts\", \"versiona el prompt\", aunque no diga la palabra prompt. NO usar para crear una skill (usar superpowers + skill-creator) ni para quitar tono de IA a un texto (usar humanizador)."
---

# Optimizador de prompts

Fusión de optimizador-prompts y prompt-engineer-toolkit. Dos niveles:

| Nivel | Cuándo | Qué hacer |
|---|---|---|
| **1. Optimizar** (por defecto) | Idea, dictado o prompt para usar ya | Proceso de abajo |
| **2. Producción** | El prompt se usará muchas veces (flujo n8n/Make, agente, plantilla de equipo, generación masiva de contenido) o pide comparar/versionar | Nivel 1 y después `modulos/prompt-engineer-toolkit/GUIA.md` |

---

## Nivel 1: optimizar

### 1. Detectar la herramienta objetivo
Texto/conversación (Claude, ChatGPT, Gemini) · código (Claude Code, Cursor) · imagen (Midjourney, Flux, Stable Diffusion, Firefly) · video (Sora, Kling, Runway, Higgsfield) · automatización (n8n, Make, Zapier, Power Automate). Si no está claro y cambia el resultado, pregunta; si no, asume la más probable y dilo.

### 2. Extraer componentes
Objetivo real · contexto (rol, situación, datos de partida) · tarea concreta · especificaciones (tono, estilo, longitud, idioma, público, restricciones) · formato de salida · criterios de calidad · qué evitar · verificación final. Si falta algo imprescindible, pregunta (máximo 2 o 3 preguntas); si no, asume y marca el supuesto.

### 3. Construir el prompt
```
[CONTEXTO Y ROL]       quién es la IA y en qué situación
[TAREA]                qué debe hacer exactamente
[ESPECIFICACIONES]     tono, longitud, idioma, público, restricciones
[CRITERIOS DE CALIDAD] cómo saber si el resultado es bueno
[FORMATO DE RESPUESTA] listas, tabla, JSON, etc.
[VERIFICACIÓN]         (opcional) autocomprobación antes de responder
```
Adapta las secciones a la herramienta; en prompts cortos de imagen o video no uses encabezados.

### Adaptación por herramienta
- **Claude / ChatGPT / Gemini:** contexto claro, pasos definidos, formato explícito. Para Claude, separar bloques con etiquetas XML (`<contexto>`, `<datos>`, `<formato>`) mejora la precisión; ejemplos dentro de `<ejemplo>`. Si es un sistema, separar system prompt y mensaje de usuario. Explicar el *por qué* de una regla funciona mejor que gritarla en mayúsculas.
- **Claude Code / programación:** objetivo, lenguaje/framework, archivos afectados, restricciones, comportamiento esperado, criterios de validación y casos límite, cómo probarlo, y si debe explicar o solo entregar.
- **Imagen:** sujeto → composición → estilo → iluminación → encuadre → relación de aspecto → mood; elementos obligatorios y a evitar. Formato de la herramienta (Midjourney `--ar`, `--style`, `--no`; SD `negative prompt:`).
- **Video:** escena inicial, movimiento de cámara, acción principal, progresión, estilo, duración, sonido, continuidad si es secuencia.
- **Automatizaciones:** disparador, entradas, pasos en orden, herramientas conectadas, salida, casos límite, manejo de errores y qué pasa si falla un paso. En Power Automate de Afinia: solo conectores estándar (`power-automate-afinia`).

### Formato de respuesta (siempre)

**Prompt optimizado:**
[prompt limpio en un bloque de código, listo para copiar]

**Cambios principales:** 3 a 5 mejoras (qué faltaba, qué se ordenó, qué se añadió).

**Dudas opcionales:** solo si mejorarían mucho el resultado (máximo 2 o 3).

---

## Nivel 2: producción

Lee `modulos/prompt-engineer-toolkit/GUIA.md` (en inglés; responde en español). Aporta:
- **Prueba A/B** de dos prompts contra casos JSON con `scripts/prompt_tester.py` (puntúa cobertura esperada, contenido prohibido, formato y longitud).
- **Versionado** con historial inmutable y diffs: `scripts/prompt_versioner.py`.
- Plantillas de marketing y reglas de gobernanza (no afirmar lo que no se puede probar, divulgación, revisión humana).

Rutas relativas a `modulos/prompt-engineer-toolkit/`. Scripts revisados el 2026-11-21 (librería estándar; el tester ejecuta el comando que tú le pases, sin shell): ejecutar con `python -I`, nunca con datos de Afinia.

## Reglas

- No inventar detalles críticos ni cambiar el objetivo original.
- No alargar el prompt más de lo necesario.
- Sin lenguaje corporativo, disclaimers ni advertencias innecesarias dentro del prompt.
- Una sola versión salvo que pida varias.
- No explicar teoría de prompting si no la pidió.
- El resultado debe ser usable de inmediato.
