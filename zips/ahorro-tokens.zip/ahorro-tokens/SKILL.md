---
name: ahorro-tokens
description: "Úsala cuando haya que gastar menos tokens o contexto: modo de respuesta concisa (\"modo conciso\", \"sé breve\", \"caveman\"), traspasar una sesión larga a una nueva (\"handoff\", \"resume para otra sesión\", \"el chat está muy largo\"), higiene de contexto antes de una tarea grande, o escribir y recortar skills, prompts, CLAUDE.md o AGENTS.md para que ocupen menos (\"optimiza esta skill\", \"recorta este prompt\"). NO usar para mejorar un prompt de usuario final (usar optimizador-prompts)."
---

# Ahorro de tokens

Fusión de 5 skills de alto rating (caveman, writing-for-agents, handoff, context-engineering, writing-skills) más las reglas oficiales de Anthropic. Lee solo el módulo que necesitas.

| Necesidad | Módulo | Leer |
|---|---|---|
| Responder con menos palabras sin perder precisión | `caveman` | `modulos/caveman/GUIA.md` |
| Pasar el trabajo a una sesión nueva | `handoff` | `modulos/handoff/GUIA.md` |
| Preparar o limpiar el contexto antes de una tarea larga | `context-engineering` | `modulos/context-engineering/GUIA.md` |
| Recortar cualquier texto que leerá una IA (skill, prompt, CLAUDE.md) | `writing-for-agents` | `modulos/writing-for-agents/GUIA.md` |
| Crear o probar una skill a fondo | `writing-skills` | `modulos/writing-skills/GUIA.md` |

Rutas internas de cada guía: relativas a su carpeta. Guías en inglés; responde en español. Si una guía cita `superpowers:<x>` o `test-driven-development`, usa la skill `desarrollo-codigo`.

## Modo conciso (resumen para no cargar el módulo)

Activo cuando el usuario lo pide y hasta que diga "modo normal". Quitar saludos, relleno, rodeos, repeticiones, resúmenes de lo ya dicho y anuncios ("ahora voy a…"). Mantener exactos el código, rutas, comandos, errores y cifras. **Volver a prosa completa** para: advertencias de seguridad, acciones irreversibles, pasos en orden, un usuario confundido, todo lo que se guarda fuera del chat (código, commits, documentos, correos) y preguntas al usuario.

## Reglas de ahorro (fuentes: docs de Anthropic "skill best practices", "skills" y "costs")

**Al escribir skills**
- SKILL.md < 500 líneas; referencias a un solo nivel; índice al inicio de referencias > 100 líneas.
- `description` ≤ 1024 caracteres, en tercera persona, dice **cuándo** usarla ("Úsala cuando…"), con el disparador principal primero (Claude Code corta descripción + when_to_use a 1536). No resumir el flujo en la descripción: el agente seguiría el resumen y no leería la skill.
- Asumir que Claude ya sabe lo general; cada párrafo debe justificar su costo. Quitar sinónimos, repeticiones, negaciones innecesarias y lo que el modelo ya hace por defecto.
- Lo determinista va en scripts: se ejecutan sin cargarse y solo su salida cuesta tokens. Decir si un archivo se **ejecuta** o se **lee**.
- Dividir referencias por dominio y buscar con grep en las grandes en vez de leerlas enteras.
- Reglas críticas arriba: tras compactar, cada skill re-adjunta solo sus primeros ~5.000 tokens.
- Una skill cargada queda en contexto todos los turnos; por eso, routers cortos + módulos.

**Al trabajar**
- CLAUDE.md < 200 líneas; los flujos van en skills.
- `/clear` entre tareas no relacionadas (gratis); `/compact <foco>` solo cuando hace falta (es una petición grande).
- Empezar sesión nueva en un límite de tarea terminada, no por conteo de tokens, tras guardar: alcance y decisiones, estado de tareas, estado del árbol de trabajo, comandos de verificación con su resultado y preguntas abiertas (módulo `handoff`).
- Mandar trabajo verboso (tests, logs, documentación larga) a subagentes; usar modelos baratos para tareas mecánicas. Los equipos de agentes gastan ~7× más.
- Preferir CLI a servidores MCP cuando ambos sirven; recortar salidas largas (`tail -n 100`, `grep`).
- Pasar artefactos entre agentes como archivos, no pegados en el chat.
