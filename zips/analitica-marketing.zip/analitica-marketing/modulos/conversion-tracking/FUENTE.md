Fuente: github.com/coreyhaines31/marketingskills (MIT), v2.14.25, commit 5b2b400, descargado y escaneado el 2026-11-21.
