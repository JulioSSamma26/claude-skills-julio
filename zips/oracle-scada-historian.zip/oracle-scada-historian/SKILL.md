---
name: "oracle-scada-historian"
description: "Consultas Oracle al historiador de Spectrum Power 7 en Afinia (HISU.his_message): eventos APPEAR/DISAPP, ABIERTO/CERRADO, disponibilidad, Oracle 9i (SGDPROD) y 12c+, y conexión Python. Incluye guías oficiales de Oracle para afinar SQL y PL/SQL (plan de ejecución, índices, cursores, errores). NO usar para SQL genérico fuera del SCADA (usar data:sql-queries)."
---

# Oracle + historiador SCADA (Spectrum Power 7)

Para escribir, revisar o depurar SQL y scripts que leen el histórico SCADA de Afinia.

## Contexto fijo

- Historiador: Spectrum Power 7, tabla de mensajes `HISU.his_message`.
- Eventos que se emparejan:
  - Comunicación: `DISAPP` (se pierde) → `APPEAR` (vuelve).
  - Interruptores: `ABIERTO` → `CERRADO`.
- `SGDPROD` (fuente BDI) es **Oracle9i 9.2.0.8.0**. Desde Python se conecta en **modo thick**, con la variable de entorno ya existente `ORA_CLIENT_LIB_DIR`.

## Reglas antes de escribir SQL

1. **Elegir la plantilla según la versión de la base.**
   - Oracle 9i (SGDPROD): solo funciones analíticas clásicas (`LAG`, `LEAD`, `ROW_NUMBER`). No existen `MATCH_RECOGNIZE`, `FETCH FIRST`, `LISTAGG`, `OFFSET`.
   - 12c o superior: se puede usar `MATCH_RECOGNIZE`.
   - Si no se sabe la versión: preguntar o proponer `SELECT * FROM v$version` antes de escribir.
2. **No inventar columnas.** Si no se conocen los nombres exactos de `HISU.his_message` (fecha, punto, texto del evento, etc.), pedir un `DESCRIBE` o 5 filas de ejemplo. Marcar los supuestos como `<COL_...>`.
3. **Solo lectura.** Únicamente `SELECT`. Nunca `INSERT`, `UPDATE`, `DELETE`, DDL ni `COMMIT` contra producción.
4. **Ventana acotada** (`fecha >= :ini AND fecha < :fin`) para no cargar el historiador. Fechas con `TO_DATE`/`TO_TIMESTAMP` y formato explícito, nunca conversiones implícitas.
5. **Reglas de calidad SQL:** variables bind siempre; nada de `SELECT *` en código que se queda; columnas de `WHERE` y `JOIN` con índice (comprobar con `EXPLAIN PLAN`); para paginar en 9i, filtrar por clave (`WHERE id > :ultimo ORDER BY id`) en vez de saltar filas; leer en bloques con `arraysize` / `fetchmany`. <!-- Adaptado de affaan-m/ECC v2.2.3 (MIT), agents/database-reviewer -->
6. **Estado al inicio de la ventana.** Un punto que ya estaba caído antes de `:ini` no tiene `DISAPP` dentro de la ventana. Leer desde `:ini_ampliado` (ej. 2 días antes) para conocer el último estado y recortar después a `:ini`.

## Plantilla A: emparejar eventos en Oracle 9i (SGDPROD)

El nivel interno quita eventos repetidos seguidos (dos `DISAPP` sin `APPEAR` en medio); el externo empareja cada caída con el retorno siguiente.

```sql
SELECT punto,
       fecha                AS inicio_falla,
       sig_fecha            AS fin_falla,
       NVL(sig_fecha, :fin) AS fin_recortado
FROM (
  SELECT punto, fecha, evento,
         LEAD(fecha) OVER (PARTITION BY punto ORDER BY fecha) AS sig_fecha
  FROM (
    SELECT punto, fecha, evento,
           LAG(evento) OVER (PARTITION BY punto ORDER BY fecha) AS ant_evento
    FROM (
      SELECT <COL_PUNTO> AS punto, <COL_FECHA> AS fecha, <COL_EVENTO> AS evento
      FROM HISU.his_message
      WHERE <COL_FECHA> >= :ini_ampliado AND <COL_FECHA> < :fin
        AND <COL_EVENTO> IN ('DISAPP','APPEAR')
    )
  )
  WHERE ant_evento IS NULL OR ant_evento <> evento
)
WHERE evento = 'DISAPP'
  AND (sig_fecha IS NULL OR sig_fecha >= :ini);
```

Para interruptores, cambiar a `'ABIERTO'`/`'CERRADO'`. Si la columna de fecha es `TIMESTAMP`, usar `CAST(<COL_FECHA> AS DATE)` antes de restar, para obtener días y no `INTERVAL`.

## Plantilla B: emparejar eventos en 12c o superior

```sql
SELECT *
FROM (
  SELECT <COL_PUNTO> AS punto, <COL_FECHA> AS fecha, <COL_EVENTO> AS evento
  FROM HISU.his_message
  WHERE <COL_FECHA> >= :ini AND <COL_FECHA> < :fin
    AND <COL_EVENTO> IN ('DISAPP','APPEAR')
)
MATCH_RECOGNIZE (
  PARTITION BY punto
  ORDER BY fecha
  MEASURES
    FIRST(caida.fecha)   AS inicio_falla,
    FIRST(retorno.fecha) AS fin_falla
  ONE ROW PER MATCH
  PATTERN (caida+ retorno{0,1})
  DEFINE
    caida   AS evento = 'DISAPP',
    retorno AS evento = 'APPEAR'
);
```

### Trampa conocida: `?` en MATCH_RECOGNIZE

El cuantificador `?` dentro de `PATTERN (...)` choca con el parseo de parámetros de JDBC y otros drivers, que lo toman como variable de enlace. **Usar siempre `{0,1}` en lugar de `?`.**

```sql
-- MAL:  PATTERN (A B?)
-- BIEN: PATTERN (A B{0,1})
```

## Disponibilidad diaria

Con los intervalos de falla (inicio, fin recortado):

1. Recortar cada intervalo a la ventana `[:ini, :fin)`.
2. Partir los intervalos que cruzan medianoche en un tramo por día. Hacerlo en Python (pandas), no en SQL, para no depender de funciones que 9i no tiene.
3. Por punto y día: `horas_falla = suma de tramos`; `horas_online = 24 - horas_falla`; `disponibilidad = horas_online / 24`.
4. Una falla sin retorno dentro de la ventana (`fin_falla` nulo) se cierra con `:fin` y se reporta aparte; no se descarta.

Si el cálculo alimenta los indicadores SOE, seguir además la skill disponibilidad-soe (regla de 10 días, plantillas).

## Python

```python
import os, oracledb
oracledb.init_oracle_client(lib_dir=os.environ["ORA_CLIENT_LIB_DIR"])  # modo thick
conn = oracledb.connect(user=os.environ["ORA_USER"],
                        password=os.environ["ORA_PASS"],
                        dsn=os.environ["ORA_DSN"])
cur = conn.cursor()
cur.execute(sql, ini=ini, ini_ampliado=ini_ampliado, fin=fin)  # variables de enlace, nunca f-strings
```

- Credenciales siempre desde variables de entorno, nunca escritas en el código.
- No cambiar la versión del Oracle Client al que apunta `ORA_CLIENT_LIB_DIR` sin probar antes: los clientes recientes no conectan a bases 9i.

## Entrega

1. El SQL o script, con la plantilla que corresponde a la versión de la base.
2. Supuestos (columnas `<COL_...>`, versión, ventana ampliada).
3. Consulta de validación: conteo de eventos por tipo y punto en la misma ventana, y número de `DISAPP` sin `APPEAR`, para comparar con el resultado.

## Afinar rendimiento y PL/SQL (guías oficiales de Oracle)

Cuando una consulta va lenta o hay que escribir o revisar PL/SQL, lee solo el archivo que aplique de `references/oracle-oficial/` (Oracle, licencia UPL-1.0, en inglés):

| Tema | Archivo | ¿Sirve en 9i (SGDPROD)? |
|---|---|---|
| Leer un plan de ejecución | `performance/explain-plan.md` | Sí, con `EXPLAIN PLAN` + `DBMS_XPLAN.DISPLAY` (sin `DISPLAY_CURSOR` en 9i) |
| Qué índice crear o pedir | `performance/index-strategy.md` | Sí |
| Estadísticas del optimizador | `performance/optimizer-stats.md` | Parcial: `DBMS_STATS` existe; las opciones nuevas no |
| Esperas, ASH, AWR, memoria | `performance/wait-events.md`, `ash-analysis.md`, `awr-reports.md`, `memory-tuning.md` | **No**: ASH y AWR son de 10g en adelante y requieren el Diagnostics Pack. En 9i usar `V$SESSION_WAIT` / Statspack |
| Cursores, colecciones, errores, rendimiento, seguridad y calidad de PL/SQL | `plsql/*.md` | Casi todo. `FORALL`/`BULK COLLECT` sí existen en 9i; `LISTAGG`, `FETCH FIRST` y las funciones nuevas no |

Reglas al usarlas:
- La línea base de las guías es 19c. Antes de proponer algo en SGDPROD, confirmar que existe en 9.2.
- En el historiador no se crean índices ni objetos por cuenta propia (solo lectura). Un índice se **propone** al DBA con el plan de ejecución que lo justifica.

## Seguridad

Nunca enviar extractos del historiador, nombres de puntos ni credenciales a servicios externos.