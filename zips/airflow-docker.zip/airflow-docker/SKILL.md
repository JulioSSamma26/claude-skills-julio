---
name: airflow-docker
description: "Úsala al escribir, probar, depurar o desplegar DAGs de Apache Airflow y al trabajar con Docker y Docker Compose (en WSL o Linux): estructura de DAGs, pruebas, DAGs que fallan o quedan colgados, docker-compose.yaml, Dockerfiles, imágenes y comandos peligrosos (rm, prune, down -v). Úsala con \"mi DAG falla\", \"escribe un DAG\", \"prueba este DAG\", \"despliega Airflow\", \"docker compose\", \"Dockerfile\", \"limpia Docker\". NO usar para el SQL del historiador (usar oracle-scada-historian) ni para depurar código Python general (usar desarrollo-codigo)."
---

# Airflow y Docker

Fusión de 8 skills oficiales: astronomer/agents (Apache-2.0) y docker/skills (Apache-2.0). Lee solo el módulo que necesitas.

| Situación | Módulo | Leer |
|---|---|---|
| Escribir o reestructurar un DAG (buenas prácticas, idempotencia, conexiones) | `authoring-dags` | `modulos/authoring-dags/GUIA.md` (+ `reference/best-practices.md`) |
| Probar DAGs (import, unidad, integración) | `testing-dags` | `modulos/testing-dags/GUIA.md` |
| Un DAG falla, se cuelga o se reintenta sin fin | `debugging-dags` | `modulos/debugging-dags/GUIA.md` |
| Desplegar Airflow (Docker Compose incluido) | `deploying-airflow` | `modulos/deploying-airflow/GUIA.md` |
| docker-compose.yaml: dependencias, volúmenes, redes, override de desarrollo | `docker-compose-patterns` | `modulos/docker-compose-patterns/GUIA.md` |
| Dockerfile: multi-stage, caché de capas, imágenes pequeñas | `docker-build-strategies` | `modulos/docker-build-strategies/GUIA.md` |
| Estructura base de un proyecto con Docker | `docker-project-foundations` | `modulos/docker-project-foundations/GUIA.md` |
| Antes de cualquier comando que borre (rm, rmi, prune, `down -v`) | `docker-destructive-guardrails` | `modulos/docker-destructive-guardrails/GUIA.md` |

Guías en inglés; responde en español. Rutas internas relativas a cada módulo.

## Reglas para el entorno de Julio (WSL + Afinia)

1. **Comandos destructivos:** antes de `docker rm`, `rmi`, `system/volume prune` o `compose down -v`, aplicar `docker-destructive-guardrails` y pedir confirmación. Un `down -v` borra la base de metadatos de Airflow y el historial de ejecuciones.
2. **Credenciales:** Oracle y correo van en Connections o Variables de Airflow, o en variables de entorno de un `.env` que no se versiona. Nunca en el código del DAG ni en el `docker-compose.yaml`.
3. **Oracle 9i (SGDPROD):** el modo thick con `ORA_CLIENT_LIB_DIR` debe estar dentro de la imagen del worker. No cambiar la versión del Instant Client sin probar antes la conexión a 9i (ver `oracle-scada-historian`).
4. **Zona horaria:** los DAGs programan en UTC. Los informes diarios de Colombia (UTC-5) usan `pendulum` con `America/Bogota` y la fecha de datos del día anterior cuando aplica.
5. **Idempotencia:** re-ejecutar un día (`airflow dags backfill` o "Clear") no debe duplicar filas ni reenviar correos. Debe coincidir con la regla de un solo envío diario de `power-automate-afinia`.
6. **WSL:** montar las carpetas del proyecto desde el sistema de archivos Linux (`~/airflow_scada`), no desde `/mnt/c`, por rendimiento y permisos. En Windows, los scripts `.sh` de los módulos se corren desde WSL.
7. **Verificar de verdad:** un DAG no "funciona" hasta que pasa `airflow dags test <dag_id> <fecha>` o una ejecución real (ver `desarrollo-codigo`, módulo verification-before-completion).
8. **CLI de Astronomer (`af`, `astro`):** las guías la mencionan, pero es opcional y envía telemetría (desactivar con `af telemetry disable`). El Airflow de Julio corre con Docker Compose, no con Astro.
