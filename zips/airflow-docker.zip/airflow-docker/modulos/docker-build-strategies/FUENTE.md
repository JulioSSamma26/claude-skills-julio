Fuente: github.com/docker/skills (Apache-2.0), commit caeee20. Descargado y escaneado el 2026-11-21. Texto original; solo SKILL.md se renombró a GUIA.md.
