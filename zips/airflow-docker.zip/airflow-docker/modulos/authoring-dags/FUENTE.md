Fuente: github.com/astronomer/agents (Apache-2.0), commit f38c558. Descargado y escaneado el 2026-11-21. Texto original; solo SKILL.md se renombró a GUIA.md.
