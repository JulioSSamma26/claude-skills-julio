Fuente: github.com/coreyhaines31/marketingskills (MIT), v2.14.25, commit 5b2b400 (2026-11-19), carpeta skills/paywalls. Descargado y escaneado el 2026-11-21.
