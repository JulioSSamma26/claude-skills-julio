# Trampas con cifras y estadísticas

<!-- Adaptado de sickn33/agentic-awesome-skills, skills/invokely-statistics (MIT) y skills/verify-citations (Apache-2.0 en origen) (licencia MIT/CC BY 4.0), commit f6f6868, revisado el 2026-11-21. Ejemplos de Afinia y los puntos marcados (*) son añadidos propios. -->

Se usa en el paso 4b del verificador. Cada punto dice qué mirar; la corrección va en la tabla de verificación.

## Recalcular
- **Totales:** las partes suman el total del texto y el de la tabla. Si no cuadra, se da la diferencia exacta.
- **Decimal corrido:** 34 % escrito como 340 %, 1,5 MW escrito como 15 MW. Compara con el orden de magnitud esperable.
- **Porcentaje o puntos porcentuales:** pasar del 10 % al 12 % son +2 puntos o +20 %, no "+2 %". (*)
- **Variación sin base:** "3 veces más", "creció un 40 %"... ¿respecto a qué y en qué periodo? Sin base, el veredicto es 🟡 o ⚠️. (*)
- **Relativo o absoluto:** "el doble de fallas" puede ser pasar de 1 a 2. (*)
- **Unidades y separadores:** kW/MW, kV/V, horas/minutos; coma decimal en Colombia y punto en textos en inglés. (*)

## Comparar y fechar
- **Periodo del dato ≠ fecha de consulta:** "el último dato" puede ser de hace dos años. Se dice el periodo al que se refiere.
- **Misma definición:** dos medidas con nombre parecido no se comparan (disponibilidad operativa frente a regulatoria, SAIDI frente a SAIFI, año fiscal frente a calendario). (ejemplos *)
- **Comparable solo si coinciden** definición, periodo, unidad y fuente; si no, se dice en la corrección.
- **Denominador pequeño:** un porcentaje sobre 5 casos no es una tendencia.
- **Proyección ≠ dato observado:** las metas y estimaciones van rotuladas como tales.
- **Etiquetas de la fuente:** si el dato es provisional, estimado o de baja fiabilidad, la etiqueta se conserva.
- **Dato faltante ≠ cero:** sin dato se escribe "sin dato"; no se rellena ni se arrastra el valor anterior.
- **"Hasta X %"** es un máximo, no lo habitual. (*)

## Al proponer la corrección
- Se da la cifra correcta con periodo, unidad y fuente, o se quita el número si no hay fuente. Nunca se cambia una cifra sin respaldo por otra que tampoco lo tiene.
