Fuente: github.com/github/awesome-copilot (MIT), commit f10fdb8. Descargado y escaneado el 2026-11-21. Texto original; solo SKILL.md se renombró a GUIA.md.
