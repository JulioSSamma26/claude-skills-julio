---
name: excel-datos
description: "Úsala para auditar fórmulas de un Excel (valores fijos dentro de fórmulas, rangos corridos, referencias circulares, vínculos rotos), limpiar datos sucios en una hoja (espacios, números como texto, fechas mezcladas, duplicados, caracteres dañados) u optimizar y explicar medidas DAX de Power BI. Úsala con \"revisa las fórmulas\", \"audita este Excel\", \"limpia estos datos\", \"optimiza esta medida DAX\", \"Power BI lento\". NO usar para crear un Excel desde cero (usar xlsx), para análisis estadístico (usar data:analyze) ni para el cálculo de disponibilidad SOE (usar disponibilidad-soe)."
---

# Excel y datos: auditar, limpiar, DAX

Fusión de 3 skills: audit-xls y clean-data-xls de Anthropic (anthropics/financial-services, Apache-2.0) y power-bi-dax-optimization (github/awesome-copilot, MIT).

| Necesidad | Módulo | Leer |
|---|---|---|
| Revisar fórmulas por rango, hoja o modelo completo; tabla de hallazgos por severidad | `audit-xls` | `modulos/audit-xls/GUIA.md` |
| Limpiar datos con columnas auxiliares auditables (o openpyxl en archivos planos) | `clean-data-xls` | `modulos/clean-data-xls/GUIA.md` |
| Medidas DAX: variables, DIVIDE, BLANK, refactor y explicación | `power-bi-dax-optimization` | `modulos/power-bi-dax-optimization/GUIA.md` |

Guías en inglés; responde en español. Estas guías asumen el complemento de Excel o archivos subidos; si trabajas con un archivo local, usa la skill `xlsx` para leer y escribir y aplica el método de la guía.

## Reglas

- **Auditar = informar primero.** No cambiar nada hasta que el usuario elija qué corregir.
- **Nunca dañar el archivo:** conservar macros (`keep_vba=True` en .xlsm), hojas ocultas, formatos, nombres definidos y vínculos. Trabajar sobre una copia.
- **Configuración regional:** Excel en español usa `;` como separador de argumentos y nombres de función traducidos (SI, BUSCARV, SUMAR.SI). Al proponer fórmulas para el usuario, darlas en la versión de su Excel; openpyxl siempre escribe en inglés con `,`.
- **Datos de Afinia** (BD_SCADA, BDI, informes regulatorios) no salen de la máquina ni se suben a servicios externos.
- Para formularios FF PP usar `presupuestos-ffpp`; esta skill puede apoyarla en la auditoría final de fórmulas.
