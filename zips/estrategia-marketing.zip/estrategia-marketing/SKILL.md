---
name: estrategia-marketing
description: "Estrategia de marketing de punta a punta: posicionamiento y mensajes (PMM), generación de demanda y CAC, lanzamientos, ideas de marketing, psicología de compra, nombre de marca, campañas multicanal y qué decisiones delegar a la IA. Úsala con \"posicionamiento\", \"estrategia de marketing\", \"cómo lanzo\", \"ideas para vender más\", \"nombre para mi marca\", \"plan de campaña\", \"arma la oferta\", \"bonos y garantía\", \"nota de prensa\". NO usar para piezas concretas (usar copywriting, anuncios, contenido) ni para negocios SaaS de precios/churn (usar growth-saas)."
---

# Estrategia de marketing: posicionamiento, demanda y lanzamientos

Skill fusionada: reúne 11 skills que antes competían entre sí. Este archivo solo enruta; el método completo de cada caso está en su módulo.

## Paso 1: elegir el módulo

| Módulo | Úsalo cuando | Leer |
|---|---|---|
| `marketing-strategy-pmm` | Posicionamiento, ICP, mensajes, GTM, inteligencia competitiva. | `modulos/marketing-strategy-pmm/GUIA.md` |
| `marketing-demand-acquisition` | Generación de demanda, mezcla de canales, CAC, partnerships. | `modulos/marketing-demand-acquisition/GUIA.md` |
| `launch-strategy` | Lanzar un producto o funcionalidad. | `modulos/launch-strategy/GUIA.md` |
| `marketing-ideas` | Lluvia de ideas y tácticas de marketing. | `modulos/marketing-ideas/GUIA.md` |
| `marketing-psychology` | Sesgos y modelos mentales aplicados a vender. | `modulos/marketing-psychology/GUIA.md` |
| `business-name-fit` | Proponer o validar el nombre de un negocio o producto. | `modulos/business-name-fit/GUIA.md` |
| `marketing-ops` | Coordinar una campaña que usa varias disciplinas a la vez. | `modulos/marketing-ops/GUIA.md` |
| `ai-decision-authority` | Decidir qué decisiones de marketing puede tomar la IA y cuáles no. | `modulos/ai-decision-authority/GUIA.md` |
| `offers` *(nuevo 2026-11)* | Diseñar la oferta: ecuación de valor, bonos, garantías, escasez honesta (tienda, servicios freelance). | `modulos/offers/GUIA.md` |
| `marketing-loops` *(nuevo 2026-11)* | Rutinas recurrentes de marketing (semanales/mensuales) que se retroalimentan. | `modulos/marketing-loops/GUIA.md` |
| `public-relations` *(nuevo 2026-11)* | Prensa y medios ganados: pitch a periodistas, newsjacking, notas de prensa. | `modulos/public-relations/GUIA.md` |

Si la petición toca dos módulos, empieza por el que produce el entregable y usa el segundo solo como apoyo. Si ninguno encaja, dilo y sugiere la skill correcta (ver `orquestador-skills`).

## Paso 2: ejecutar

Lee el `GUIA.md` del módulo y sigue su proceso y formato de salida. Anuncia en una línea el módulo usado, por ejemplo: "Uso estrategia-marketing → `marketing-strategy-pmm`".

## Reglas comunes

- **Contexto primero:** si existe `.agents/product-marketing.md`, `.claude/product-marketing-context.md` o `.agents/marketing-context.md`, léelo antes de empezar. Si no existe y la tarea es de estrategia, sugiere una vez la skill `marketing-context`; para tareas pequeñas, sigue sin él.
- **Carga mínima:** lee solo `modulos/<modulo>/GUIA.md` del módulo elegido (máximo 2 módulos por tarea). Las rutas que aparecen dentro de cada guía (`references/`, `scripts/`, `assets/`, `templates/`) son relativas a la carpeta de ese módulo.
- **Idioma:** responde en el idioma del usuario (español por defecto) aunque la guía esté en inglés. Adapta ejemplos a Colombia/LatAm cuando aplique (COP, WhatsApp, Mercado Libre, Instagram).
- **Datos:** nunca inventes métricas, clientes ni resultados; si falta un número, déjalo como `{{dato}}` y pídelo.
- **Scripts de terceros** (revisados el 2026-11-21: solo librería estándar, sin exfiltración): ejecútalos con `python -I`, con datos ficticios o del proyecto de marketing, nunca con datos de Afinia. Los que aceptan URL solo descargan la URL que se les pasa.
- **Textos finales** que se van a publicar: pásalos por `humanizador` antes de entregarlos.

## Nombres antiguos (las guías pueden citarlos)

Si una guía dice "usa la skill X", traduce X a la skill actual:

| Nombre antiguo | Skill actual |
|---|---|
| page-cro, form-cro, popup-cro, signup-flow-cro, onboarding-cro, paywall-upgrade-cro | `cro` |
| seo-audit, schema-markup, site-architecture, programmatic-seo, competitor-alternatives, aeo, ai-seo, local-seo-manager | `seo` |
| social-content, social-media-manager, social-media-analyzer, x-twitter-growth | `redes-sociales` |
| copywriting, copy-editing | `copywriting` |
| cold-email, email-sequence | `email-marketing` |
| paid-ads, ad-creative | `anuncios` |
| content-strategy, content-production, content-creator, video-content-strategist | `contenido` |
| analytics-tracking, campaign-analytics, ab-test-setup | `analitica-marketing` |
| marketing-strategy-pmm, marketing-demand-acquisition, launch-strategy, marketing-ideas, marketing-psychology, business-name-fit, marketing-ops, ai-decision-authority | `estrategia-marketing` |
| pricing-strategy, churn-prevention, referral-program, free-tool-strategy, webinar-marketing, app-store-optimization | `growth-saas` |
| ads, ad-creative | `anuncios` |
| emails, cold-email, sms, prospecting, lead-magnets | `email-marketing` |
| social, influencer-marketing | `redes-sociales` |
| pricing, offers | `growth-saas` (precios) / `estrategia-marketing` (ofertas) |
| ai-seo, link-building, directory-submissions | `seo` |
| video, image | `contenido` / `optimizador-prompts` |
| conversion-tracking, analytics | `analitica-marketing` |
| marketing-plan, marketing-loops, public-relations, competitor-profiling, marketing-council | `estrategia-marketing` |
| content-humanizer, ai-tells | `humanizador` |
| prompt-engineer-toolkit | `optimizador-prompts` |

Una skill citada que no está en la tabla ni instalada (p. ej. `customer-research`, `sales-enablement`): sigue sin ella.
