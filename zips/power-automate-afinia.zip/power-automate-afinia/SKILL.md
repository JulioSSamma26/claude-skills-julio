---
name: "power-automate-afinia"
description: "Diseño y revisión de flujos Power Automate de Julio en Afinia: solo conectores estándar, envío diario por archivos disparadores y consecutivo único entre flujos sin duplicados. NO usar para n8n u otras plataformas."
---

# Power Automate: flujos de Afinia

Para crear, revisar o corregir flujos de Power Automate de Julio.

## Flujos en alcance

| Flujo | Empresa |
|---|---|
| Señales Activas | ATENEA / AFINIA |
| Enviar correo TT1_OT_ORCL | ATENEA / AFINIA |
| SoE | ATENEA / AFINIA |
| Consecutivo del modo web | correos que Julio redacta, responde o reenvía desde Outlook web |

## Regla 1: solo conectores estándar

Ningún conector Premium, para que el flujo funcione desde cualquier cuenta sin licencias adicionales.

- Permitidos: SharePoint, OneDrive para la Empresa, Excel Online (Business), Office 365 Outlook, Microsoft Teams, Aprobaciones, Programación y controles integrados.
- Prohibidos: cualquier conector con etiqueta **Premium** (HTTP, SQL Server, Oracle por gateway, Dataverse, conectores personalizados).
- Ante la duda, revisar la etiqueta "Premium" en el diseñador. Si algo solo se puede hacer con Premium, decirlo y proponer otra ruta: que Python o Airflow generen el archivo y el flujo solo lo envíe.

## Regla 2: envío diario por archivo disparador

1. Cada mañana un proceso externo (Python o Airflow) genera los archivos disparadores.
2. El flujo se activa cuando aparece el archivo en SharePoint u OneDrive.
3. Envía **una vez al día**. Antes de enviar, comprobar en el registro que ese flujo no tiene ya un correo Enviado con la misma FechaDatos; si lo tiene, no reenviar.
4. Si el disparador no llega, el flujo no inventa datos: no envía, o envía un aviso de "sin datos".

### Fecha en el asunto

- **SoE:** el archivo de cada día trae todos los registros que SCADA SP7 generó el **día anterior**, así que el asunto lleva la fecha de ayer en hora de Colombia:
  `formatDateTime(addDays(convertFromUtc(utcNow(),'SA Pacific Standard Time'),-1),'yyyy-MM-dd')`
- Los demás flujos: confirmar con Julio qué fecha cubren los datos antes de asumir.
- Nunca usar `utcNow()` sin convertir: entre las 19:00 y las 24:00 de Colombia ya es el día siguiente en UTC.

## Regla 3: consecutivo único entre todos los flujos

Cada correo enviado lleva su propio número y dos flujos nunca comparten número.

### Por qué el control de simultaneidad no basta

El control de simultaneidad del desencadenador (grado 1) solo serializa las ejecuciones **de un mismo flujo**. Los seis flujos se disparan casi a la misma hora, así que dos flujos distintos pueden leer el mismo máximo y crear el mismo número. La unicidad la debe garantizar la lista, no el flujo.

### Registro central

Lista de SharePoint `ConsecutivoCorreo` con columnas: Flujo, Fecha, Consecutivo (número), IdCorreo, Estado (Reservado / Enviado / Fallido / Anulado), FechaDatos.

- En la columna **Consecutivo** activar **"Exigir valores únicos"** (SharePoint indexa la columna). Si dos flujos intentan el mismo número, la segunda creación falla en vez de duplicar.
- La lectura del último número es siempre por el máximo global, no filtrada por flujo.

### Secuencia en el flujo (todo con conectores estándar)

1. Desencadenador con control de simultaneidad activado, grado 1.
2. Inicializar variables: `vCreado` (booleano, false), `vIntentos` (entero, 0), `vConsecutivo` (entero).
3. **Hacer hasta** `vCreado = true` o `vIntentos = 5`:
   a. **Obtener elementos** de `ConsecutivoCorreo`, Ordenar por `Consecutivo desc`, Recuento superior `1`.
   b. Establecer `vConsecutivo`:
      `if(empty(body('Obtener_elementos')?['value']), 1, add(int(first(body('Obtener_elementos')?['value'])?['Consecutivo']), 1))`
   c. **Crear elemento** con Consecutivo = `vConsecutivo`, Estado = Reservado, Flujo, Fecha, FechaDatos.
   d. Si *Crear elemento* tuvo éxito: `vCreado = true`.
   e. Si falló (Configurar ejecución después de → "ha fallado"): incrementar `vIntentos` y **Retraso** de `rand(2,10)` segundos para que los flujos no vuelvan a chocar.
4. Si tras el bucle `vCreado` sigue en false: no enviar, avisar a Julio por Teams o correo y terminar con estado Erróneo.
5. Enviar el correo con el número `vConsecutivo`.
6. **Actualizar elemento**: Estado = Enviado e IdCorreo. Si el envío falla, Estado = Fallido con la causa, para que no queden números huérfanos sin explicar.

Complemento: escalonar los disparadores de los seis flujos unos minutos entre sí para reducir reintentos.

### Consecutivo del modo web

- Reserva el siguiente número del mismo registro central, con la misma secuencia de reintento.
- El número solo queda **confirmado cuando el correo se envía de verdad**.
- Si queda en borrador o no se envía, la reserva se pierde: a las 24 h pasa a Estado = Anulado. El número anulado no se reutiliza.

## Reglas de Microsoft para construir y depurar flujos

Adaptadas de microsoft/power-platform-skills (MIT): build-flow, create-flow, debug-flow, diagnose-flow. Esas skills usan un servidor MCP (FlowAgent) que aquí no se instala; se toman solo sus reglas.

- **Nunca adivinar parámetros de un conector** (nombres, valores permitidos, tipo de acción). Confirmarlos en el diseñador o en Microsoft Learn antes de escribir la acción o la expresión.
- **El desencadenador HTTP ("Cuando se recibe una solicitud HTTP") es Premium.** No usarlo; para que otro flujo llame a este, usar un desencadenador manual o el archivo disparador.
- **Expresiones:** `result('Ambito')` solo funciona dentro de Ámbito, Aplicar a cada uno, Hasta o Switch. Para un try/catch: un Ámbito "Intentar" y un Ámbito "Capturar" con *Configurar ejecución después de* → "ha fallado / ha agotado el tiempo".
- **Depurar con evidencia, no con suposiciones:**
  1. Si el flujo no tiene ejecuciones en el historial, decirlo tal cual y revisar el desencadenador. No inventar una falla.
  2. Mapear el orden real con las dependencias *ejecutar después de* y ubicar la **primera** acción que falló, no la última.
  3. En un bucle, revisar la iteración concreta que falló.
  4. Por tipo de error: `ExpressionEvaluationFailed` / `InvalidTemplate` → mostrar la expresión y la corrección; `ActionTimedOut` → directiva de reintento o dividir la operación; 429 → limitación (throttling): espaciar o reducir el paralelismo.
  5. Después de corregir, probar con una ejecución real (o reenviar la ejecución original) antes de darlo por resuelto.

## Documentación de cambios

Toda corrección, cambio, entrada de control de cambios o mejora continua (prácticas ITIL) aplicada a cualquiera de los seis flujos se documenta en el **informe propio de ese flujo**, con fecha, qué cambió, motivo y quién lo aprobó.

## Lista de chequeo para revisar un flujo

- [ ] Ningún conector Premium.
- [ ] Disparador por archivo y control de simultaneidad activo.
- [ ] Columna Consecutivo con valores únicos y bucle de reintento.
- [ ] Consecutivo reservado antes de enviar y marcado Enviado o Fallido después.
- [ ] No reenvía si ya existe un envío con la misma FechaDatos.
- [ ] Fecha del asunto correcta (SoE = día anterior, hora Colombia).
- [ ] Manejo de error con "Configurar ejecución después de".
- [ ] Correo con responsables, acciones y fechas claramente diferenciados.
- [ ] Sin direcciones, rutas ni credenciales escritas a mano; variables al inicio.
- [ ] Cambio documentado en el informe del flujo.

## Entrega

Paso a paso en el orden del diseñador, con el nombre de cada acción y las expresiones exactas. Indicar qué cambia respecto a la versión anterior e incluir el texto listo para pegar en el informe de control de cambios del flujo.